"""Запуск и управление локальным llama.cpp server."""

from __future__ import annotations

import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from app.utils.constants import BASE_DIR, DEFAULT_LLAMA_MODEL, LLAMA_DIR, MODELS_DIR
from app.utils.config import SettingsManager

SERVER_EXE_NAMES = ("llama-server.exe", "server.exe", "llama-server")
STARTUP_TIMEOUT_SEC = 120
POLL_INTERVAL_SEC = 1.0


class LlamaServerManager:
    def __init__(self, settings: SettingsManager) -> None:
        self.settings = settings
        self._process: subprocess.Popen | None = None

    @property
    def host(self) -> str:
        return str(self.settings.get("llama_host", "127.0.0.1")).strip() or "127.0.0.1"

    @property
    def port(self) -> int:
        return int(self.settings.get("llama_port", 8080))

    @property
    def api_base_url(self) -> str:
        return f"http://{self.host}:{self.port}/v1"

    def resolve_model_path(self) -> Path | None:
        configured = str(self.settings.get("llama_model_path", "") or "").strip()
        candidates: list[Path] = []

        if configured:
            path = Path(configured)
            if not path.is_absolute():
                path = BASE_DIR / path
            candidates.append(path)

        candidates.append(MODELS_DIR / DEFAULT_LLAMA_MODEL)
        for path in MODELS_DIR.glob("*.gguf"):
            candidates.append(path)

        seen: set[Path] = set()
        for path in candidates:
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            if resolved.is_file():
                return resolved
        return None

    def resolve_server_exe(self) -> Path | None:
        configured = str(self.settings.get("llama_server_exe", "") or "").strip()
        candidates: list[Path] = []

        if configured:
            path = Path(configured)
            if not path.is_absolute():
                path = BASE_DIR / path
            candidates.append(path)

        search_roots = [
            LLAMA_DIR,
            LLAMA_DIR / "build" / "bin" / "Release",
            LLAMA_DIR / "build" / "bin",
            BASE_DIR / "llama-cpp",
            BASE_DIR,
        ]
        for root in search_roots:
            if not root.exists():
                continue
            for name in SERVER_EXE_NAMES:
                candidates.append(root / name)
            try:
                for path in root.rglob("llama-server.exe"):
                    candidates.append(path)
            except OSError:
                pass

        seen: set[Path] = set()
        for path in candidates:
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            if resolved.is_file():
                return resolved
        return None

    def is_port_open(self) -> bool:
        try:
            with socket.create_connection((self.host, self.port), timeout=1.5):
                return True
        except OSError:
            return False

    def is_responding(self) -> bool:
        if not self.is_port_open():
            return False
        url = f"http://{self.host}:{self.port}/health"
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                return response.status == 200
        except urllib.error.HTTPError as exc:
            return exc.code < 500
        except OSError:
            return self.is_port_open()

    def is_managed_running(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def status_message(self) -> str:
        model = self.resolve_model_path()
        exe = self.resolve_server_exe()
        if self.is_responding():
            return f"Локальный сервер работает ({self.host}:{self.port})"
        if not model:
            return "Модель .gguf не найдена. Положите файл в папку models/"
        if not exe:
            return "llama-server.exe не найден. Положите llama.cpp в папку llama.cpp/"
        return f"Сервер не запущен ({self.host}:{self.port})"

    def build_command(self, model_path: Path, server_exe: Path) -> list[str]:
        ctx = int(self.settings.get("llama_context_size", 8192))
        gpu_layers = int(self.settings.get("llama_gpu_layers", -1))
        threads = int(self.settings.get("llama_threads", 0))
        model_alias = str(self.settings.get("model", "local") or "local").strip()

        cmd = [
            str(server_exe),
            "-m",
            str(model_path),
            "--host",
            self.host,
            "--port",
            str(self.port),
            "-c",
            str(ctx),
            "--alias",
            model_alias,
        ]
        if gpu_layers >= 0:
            cmd.extend(["-ngl", str(gpu_layers)])
        if threads > 0:
            cmd.extend(["-t", str(threads)])
        return cmd

    def start(self) -> tuple[bool, str]:
        if self.is_responding():
            return True, self.status_message()

        model_path = self.resolve_model_path()
        if not model_path:
            return False, (
                "Файл модели не найден.\n\n"
                f"Положите Qwen2.5-14B-Instruct-IQ2_M.gguf в:\n{MODELS_DIR}"
            )

        server_exe = self.resolve_server_exe()
        if not server_exe:
            return False, (
                "llama-server.exe не найден.\n\n"
                f"Распакуйте сборку llama.cpp в:\n{LLAMA_DIR}"
            )

        if self.is_port_open():
            return False, (
                f"Порт {self.port} уже занят другим процессом.\n"
                "Измените порт в настройках или остановите другой сервер."
            )

        cmd = self.build_command(model_path, server_exe)
        creationflags = 0
        if sys.platform == "win32":
            creationflags = subprocess.CREATE_NO_WINDOW

        try:
            self._process = subprocess.Popen(
                cmd,
                cwd=str(server_exe.parent),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
        except OSError as exc:
            self._process = None
            return False, f"Не удалось запустить llama-server:\n{exc}"

        deadline = time.monotonic() + STARTUP_TIMEOUT_SEC
        while time.monotonic() < deadline:
            if self._process.poll() is not None:
                self._process = None
                return False, (
                    "llama-server завершился с ошибкой при запуске.\n"
                    "Проверьте путь к модели, версию llama.cpp и наличие VRAM/RAM."
                )
            if self.is_responding():
                return True, self.status_message()
            time.sleep(POLL_INTERVAL_SEC)

        return False, (
            "Сервер не ответил в течение 2 минут.\n"
            "Первый запуск большой модели может занять больше времени — "
            "попробуйте «Проверить подключение» позже."
        )

    def stop(self) -> None:
        if self._process is None:
            return
        if self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._process.kill()
        self._process = None

    def ensure_running(self) -> tuple[bool, str]:
        if self.is_responding():
            return True, self.status_message()
        return self.start()
