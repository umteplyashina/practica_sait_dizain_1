"""Хранение диалогов и смет на диске для открытия позже."""

from __future__ import annotations

import json
import re
import uuid
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from app.services.estimate_exporter import extract_estimate_from_messages, looks_like_estimate
from app.utils.constants import SESSIONS_DIR


def _now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _safe_title(text: str, fallback: str = "Без названия") -> str:
    cleaned = re.sub(r"\s+", " ", (text or "").strip())
    cleaned = cleaned.replace("\n", " ")
    if not cleaned:
        return fallback
    return cleaned[:80]


@dataclass
class ChatSession:
    id: str
    title: str
    created_at: str
    updated_at: str
    mode: str = "free"
    messages: list[dict[str, str]] = field(default_factory=list)
    has_estimate: bool = False

    @classmethod
    def create(cls, mode: str = "free") -> "ChatSession":
        stamp = _now_iso()
        return cls(
            id=uuid.uuid4().hex[:12],
            title="Новый диалог",
            created_at=stamp,
            updated_at=stamp,
            mode=mode,
            messages=[],
            has_estimate=False,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ChatSession":
        messages = data.get("messages") or []
        clean_messages: list[dict[str, str]] = []
        for msg in messages:
            if not isinstance(msg, dict):
                continue
            role = str(msg.get("role", "")).strip()
            content = str(msg.get("content", ""))
            if role and content is not None:
                clean_messages.append({"role": role, "content": content})
        return cls(
            id=str(data.get("id") or uuid.uuid4().hex[:12]),
            title=str(data.get("title") or "Без названия"),
            created_at=str(data.get("created_at") or _now_iso()),
            updated_at=str(data.get("updated_at") or _now_iso()),
            mode=str(data.get("mode") or "free"),
            messages=clean_messages,
            has_estimate=bool(data.get("has_estimate", False)),
        )


class SessionStore:
    def __init__(self, root: Path = SESSIONS_DIR) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "index.json"
        self.last_path = self.root / "last_session.txt"

    def _session_path(self, session_id: str) -> Path:
        return self.root / f"{session_id}.json"

    def list_sessions(self) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        for path in self.root.glob("*.json"):
            if path.name == "index.json":
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            session = ChatSession.from_dict(data)
            preview = ""
            for msg in reversed(session.messages):
                if msg.get("role") == "user" and msg.get("content"):
                    preview = msg["content"].strip().replace("\n", " ")[:100]
                    break
            items.append(
                {
                    "id": session.id,
                    "title": session.title,
                    "updated_at": session.updated_at,
                    "created_at": session.created_at,
                    "mode": session.mode,
                    "has_estimate": session.has_estimate,
                    "message_count": len(session.messages),
                    "preview": preview,
                }
            )
        items.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        self._write_index(items)
        return items

    def _write_index(self, items: list[dict[str, Any]]) -> None:
        try:
            self.index_path.write_text(
                json.dumps(items, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError:
            pass

    def load(self, session_id: str) -> ChatSession | None:
        path = self._session_path(session_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        return ChatSession.from_dict(data)

    def save(self, session: ChatSession) -> Path:
        session.updated_at = _now_iso()
        session.has_estimate = self._detect_estimate(session.messages)
        session.title = self._make_title(session)
        path = self._session_path(session.id)
        path.write_text(
            json.dumps(session.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        self.set_last_session_id(session.id)
        self.list_sessions()
        return path

    def delete(self, session_id: str) -> bool:
        path = self._session_path(session_id)
        if not path.exists():
            return False
        try:
            path.unlink()
        except OSError:
            return False
        if self.get_last_session_id() == session_id:
            self.last_path.unlink(missing_ok=True)
        self.list_sessions()
        return True

    def rename(self, session_id: str, title: str) -> ChatSession | None:
        session = self.load(session_id)
        if not session:
            return None
        session.title = _safe_title(title, session.title)
        self.save(session)
        return session

    def set_last_session_id(self, session_id: str) -> None:
        try:
            self.last_path.write_text(session_id, encoding="utf-8")
        except OSError:
            pass

    def get_last_session_id(self) -> str | None:
        if not self.last_path.exists():
            return None
        try:
            value = self.last_path.read_text(encoding="utf-8").strip()
        except OSError:
            return None
        return value or None

    def load_last(self) -> ChatSession | None:
        session_id = self.get_last_session_id()
        if not session_id:
            return None
        return self.load(session_id)

    def update_from_chat(
        self,
        session: ChatSession,
        *,
        messages: list[dict[str, str]],
        mode: str,
    ) -> ChatSession:
        session.messages = deepcopy(messages)
        session.mode = mode
        self.save(session)
        return session

    @staticmethod
    def _detect_estimate(messages: list[dict[str, str]]) -> bool:
        for msg in reversed(messages):
            if msg.get("role") == "assistant" and looks_like_estimate(msg.get("content", "")):
                return True
        return extract_estimate_from_messages(messages) is not None

    @staticmethod
    def _make_title(session: ChatSession) -> str:
        if session.title and session.title not in {"Новый диалог", "Без названия"}:
            # Keep custom title unless still default-ish and we can improve it
            if not session.title.startswith("Новый диалог"):
                return session.title

        table = extract_estimate_from_messages(session.messages)
        if table and table.title and table.title != "Смета":
            return _safe_title(table.title)

        for msg in session.messages:
            if msg.get("role") == "user" and msg.get("content"):
                text = msg["content"].split("\n--- Документ:", 1)[0].strip()
                if text:
                    return _safe_title(text)

        if session.has_estimate:
            return f"Смета от {datetime.now():%d.%m.%Y}"
        return f"Диалог от {datetime.fromisoformat(session.created_at):%d.%m.%Y %H:%M}"
