"""Клиент для работы с AI API."""

import threading
from typing import Callable

from openai import OpenAI

from app.services.llama_server import LlamaServerManager
from app.utils.constants import (
    BASE_DIR,
    BOT_PROMPT_FILENAME,
    PROMPT_FILENAME,
    RESOURCE_DIR,
    SYSTEM_PROMPT_FILE,
)
from app.services.estimate_exporter import ESTIMATE_HINT
from app.utils.config import SettingsManager
from app.utils.api_errors import format_api_error

PROMPT_CANDIDATES: dict[str, list] = {
    "app": [
        SYSTEM_PROMPT_FILE,
        BASE_DIR / PROMPT_FILENAME,
        RESOURCE_DIR / PROMPT_FILENAME,
    ],
    "bot": [
        RESOURCE_DIR / "prompts" / "bot_prompt.md",
        BASE_DIR / BOT_PROMPT_FILENAME,
        RESOURCE_DIR / BOT_PROMPT_FILENAME,
    ],
}

FALLBACK_PROMPTS: dict[str, str] = {
    "app": "Ты — профессиональный AI-помощник сметчика в строительстве.",
    "bot": (
        "Ты — ИИ-помощник по сметному делу в строительстве. "
        "Помогай составлять, проверять и анализировать сметы. "
        "Не выдумывай цены и нормативы."
    ),
}

API_TIMEOUT_SECONDS = 120.0


class AIClient:
    def __init__(self, settings: SettingsManager) -> None:
        self.settings = settings
        self._client: OpenAI | None = None
        self._system_prompts: dict[str, str] = {}
        self.llama_server = LlamaServerManager(settings)

    def _get_client(self) -> OpenAI:
        provider = self.settings.get("provider", "openai")
        if provider == "llama_cpp":
            ok, msg = self.llama_server.ensure_running()
            if not ok:
                raise ValueError(msg)
            base_url = self.llama_server.api_base_url
            api_key = "llama-local"
        else:
            api_key = self.settings.get("api_key", "").strip()
            if not api_key:
                raise ValueError(
                    "API-ключ не настроен. Откройте «Настройки» и укажите ключ."
                )
            base_url = self.settings.get_api_base_url()

        if self._client is None or getattr(self, "_client_base_url", None) != base_url:
            self._client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=API_TIMEOUT_SECONDS,
            )
            self._client_base_url = base_url
        return self._client

    def load_system_prompt(self, prompt_id: str = "app") -> str:
        if prompt_id not in PROMPT_CANDIDATES:
            prompt_id = "app"
        if prompt_id in self._system_prompts:
            return self._system_prompts[prompt_id]

        for path in PROMPT_CANDIDATES[prompt_id]:
            if path.exists():
                self._system_prompts[prompt_id] = path.read_text(encoding="utf-8")
                break
        else:
            self._system_prompts[prompt_id] = FALLBACK_PROMPTS.get(
                prompt_id, FALLBACK_PROMPTS["app"]
            )
        return self._system_prompts[prompt_id]

    def _build_system_message(
        self, mode_prompt: str = "", system_prompt_id: str = "app"
    ) -> str:
        base = self.load_system_prompt(system_prompt_id)
        extras: list[str] = []

        normative = self.settings.get("normative_base", "").strip()
        if normative and normative != "Не указана":
            extras.append(f"Нормативная база пользователя: {normative}.")

        currency = self.settings.get("currency", "").strip()
        if currency:
            extras.append(f"Валюта расчётов: {currency}.")

        if mode_prompt:
            extras.append(mode_prompt)

        extras.append(ESTIMATE_HINT)

        if extras:
            return base + "\n\n---\n\n" + "\n".join(extras)
        return base

    def chat(
        self,
        messages: list[dict[str, str]],
        mode_prompt: str = "",
        system_prompt_id: str = "app",
        on_chunk: Callable[[str], None] | None = None,
        cancel_event: threading.Event | None = None,
    ) -> str:
        client = self._get_client()
        system_msg = self._build_system_message(mode_prompt, system_prompt_id)

        api_messages = [{"role": "system", "content": system_msg}] + messages

        max_tokens = int(self.settings.get("max_tokens", 4096))

        try:
            response = client.chat.completions.create(
                model=self.settings.get("model", "gpt-4o-mini"),
                messages=api_messages,
                temperature=float(self.settings.get("temperature", 0.3)),
                max_tokens=max_tokens,
                stream=on_chunk is not None,
            )
        except Exception as exc:
            raise RuntimeError(format_api_error(exc)) from exc

        if on_chunk is not None:
            full_text = ""
            for chunk in response:
                if cancel_event and cancel_event.is_set():
                    break
                delta = chunk.choices[0].delta.content or ""
                if delta:
                    full_text += delta
                    on_chunk(delta)
            if cancel_event and cancel_event.is_set():
                raise InterruptedError("Генерация остановлена пользователем.")
            return full_text

        return response.choices[0].message.content or ""

    def reset_client(self) -> None:
        self._client = None
        self._client_base_url = None

    def test_connection(self) -> tuple[bool, str]:
        provider = self.settings.get("provider", "openai")
        if provider == "llama_cpp":
            model = self.llama_server.resolve_model_path()
            if not model:
                return False, (
                    "Файл модели не найден.\n\n"
                    "Положите Qwen2.5-14B-Instruct-IQ2_M.gguf в папку models/ "
                    "и укажите путь в настройках."
                )
            exe = self.llama_server.resolve_server_exe()
            if not exe:
                return False, (
                    "llama-server.exe не найден.\n\n"
                    "Распакуйте сборку llama.cpp в папку llama.cpp/ проекта."
                )
            ok, msg = self.llama_server.ensure_running()
            if not ok:
                return False, msg
            try:
                client = self._get_client()
                client.models.list()
                return True, f"Локальный сервер готов.\nМодель: {model.name}"
            except Exception as exc:
                return False, format_api_error(exc)

        try:
            client = self._get_client()
            client.models.list()
            return True, "Подключение успешно!"
        except Exception as exc:
            return False, format_api_error(exc)
