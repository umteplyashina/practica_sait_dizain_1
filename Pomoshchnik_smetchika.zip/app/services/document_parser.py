"""Парсинг строительных документов."""

from pathlib import Path


class DocumentParser:
    MAX_CHARS = 80_000
    MAX_ROWS_PER_SHEET = 2_000

    @classmethod
    def parse(cls, file_path: str | Path) -> tuple[str, str]:
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Файл не найден: {path}")

        suffix = path.suffix.lower()
        parsers = {
            ".txt": cls._parse_text,
            ".md": cls._parse_text,
            ".csv": cls._parse_text,
            ".xlsx": cls._parse_xlsx,
            ".xls": cls._parse_xls,
            ".docx": cls._parse_docx,
            ".pdf": cls._parse_pdf,
        }

        parser = parsers.get(suffix)
        if not parser:
            raise ValueError(
                f"Неподдерживаемый формат: {suffix}. "
                f"Поддерживаются: {', '.join(sorted(parsers))}"
            )

        content = parser(path)
        content = cls._truncate(content, cls.MAX_CHARS)
        doc_type = cls._detect_type(path.name, content)
        return content, doc_type

    @classmethod
    def truncate_for_api(cls, content: str) -> str:
        return cls._truncate(content, cls.MAX_CHARS)

    @staticmethod
    def _parse_text(path: Path) -> str:
        for encoding in ("utf-8", "cp1251", "latin-1"):
            try:
                return path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                continue
        raise ValueError(f"Не удалось прочитать файл: {path.name}")

    @staticmethod
    def _parse_xlsx(path: Path) -> str:
        from openpyxl import load_workbook

        max_rows = DocumentParser.MAX_ROWS_PER_SHEET
        wb = load_workbook(path, read_only=True, data_only=True)
        lines: list[str] = []
        for sheet in wb.worksheets:
            lines.append(f"=== Лист: {sheet.title} ===")
            for row_idx, row in enumerate(sheet.iter_rows(values_only=True)):
                if row_idx >= max_rows:
                    lines.append(
                        f"[... лист обрезан, показано {max_rows} строк ...]"
                    )
                    break
                cells = [str(c) if c is not None else "" for c in row]
                if any(cells):
                    lines.append("\t".join(cells))
        wb.close()
        return "\n".join(lines)

    @staticmethod
    def _parse_xls(path: Path) -> str:
        import xlrd

        max_rows = DocumentParser.MAX_ROWS_PER_SHEET
        book = xlrd.open_workbook(str(path))
        lines: list[str] = []
        for sheet in book.sheets():
            lines.append(f"=== Лист: {sheet.name} ===")
            row_limit = min(sheet.nrows, max_rows)
            for row_idx in range(row_limit):
                cells = [str(sheet.cell_value(row_idx, col)) for col in range(sheet.ncols)]
                if any(c.strip() for c in cells):
                    lines.append("\t".join(cells))
            if sheet.nrows > max_rows:
                lines.append(
                    f"[... лист обрезан, показано {max_rows} строк ...]"
                )
        return "\n".join(lines)

    @staticmethod
    def _parse_docx(path: Path) -> str:
        from docx import Document

        doc = Document(path)
        parts: list[str] = []

        for para in doc.paragraphs:
            if para.text.strip():
                parts.append(para.text)

        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    parts.append("\t".join(cells))

        return "\n".join(parts)

    @staticmethod
    def _parse_pdf(path: Path) -> str:
        from pypdf import PdfReader

        reader = PdfReader(path)
        pages: list[str] = []
        for i, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            if text.strip():
                pages.append(f"--- Страница {i} ---\n{text}")
        return "\n\n".join(pages)

    @classmethod
    def _truncate(cls, content: str, limit: int | None = None) -> str:
        max_chars = limit if limit is not None else cls.MAX_CHARS
        if len(content) <= max_chars:
            return content
        half = max_chars // 2
        return (
            content[:half]
            + f"\n\n[... документ обрезан, показано {max_chars:,} из {len(content):,} символов ...]\n\n"
            + content[-half:]
        )

    @staticmethod
    def _detect_type(filename: str, content: str) -> str:
        name_lower = filename.lower()
        content_lower = content.lower()

        keywords = [
            ("локальная смета", "локальная смета"),
            ("ведомость объём", "ведомость объёмов работ"),
            ("ведомость объем", "ведомость объёмов работ"),
            ("дефектная ведомость", "дефектная ведомость"),
            ("спецификац", "спецификация"),
            ("коммерческ", "коммерческое предложение"),
            ("акт выполнен", "акт выполненных работ"),
            ("ресурсная ведомость", "ресурсная ведомость"),
            ("прайс", "прайс-лист"),
            ("техническое задание", "техническое задание"),
            ("тер-", "локальная смета (ТЕР)"),
            ("фер-", "локальная смета (ФЕР)"),
            ("гэсн", "смета (ГЭСН)"),
        ]

        for keyword, doc_type in keywords:
            if keyword in name_lower or keyword in content_lower[:3000]:
                return doc_type

        return "строительный документ"
