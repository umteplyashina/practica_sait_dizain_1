"""Выгрузка сметы из ответа помощника в Excel, CSV, Word и Markdown."""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

DEFAULT_HEADERS = ["№", "Наименование", "Ед. изм.", "Количество", "Цена", "Сумма", "Примечание"]

ESTIMATE_HINT = (
    "Когда составляешь смету, КП или ведомость работ, обязательно оформи позиции "
    "в виде markdown-таблицы с колонками:\n"
    "| № | Наименование | Ед. изм. | Количество | Цена | Сумма | Примечание |\n"
    "В конце добавь строку ИТОГО. Таблица нужна для выгрузки в Excel заказчику."
)

_MD_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
_SEP_ROW = re.compile(r"^\s*\|?[\s:\-|]+\|?\s*$")
_TOTAL_HINT = re.compile(r"(итог|всего|сумма\s*смети|итого)", re.IGNORECASE)


@dataclass
class EstimateTable:
    title: str = "Смета"
    headers: list[str] = field(default_factory=lambda: list(DEFAULT_HEADERS))
    rows: list[list[str]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    source_text: str = ""

    @property
    def has_data(self) -> bool:
        return bool(self.rows)


def _split_md_cells(line: str) -> list[str]:
    match = _MD_ROW.match(line)
    if not match:
        return []
    return [c.strip() for c in match.group(1).split("|")]


def _is_separator(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if not ("|" in stripped or "-" in stripped):
        return False
    cells = _split_md_cells(stripped) if "|" in stripped else [stripped]
    if not cells and _SEP_ROW.match(stripped):
        return True
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells if c)


def _looks_like_header(cells: list[str]) -> bool:
    joined = " ".join(cells).lower()
    keys = ("наимен", "работ", "единиц", "кол", "цена", "стоим", "сумм", "ед.", "объём", "объем")
    return sum(1 for k in keys if k in joined) >= 2


def parse_markdown_tables(text: str) -> list[EstimateTable]:
    lines = text.splitlines()
    tables: list[EstimateTable] = []
    i = 0
    while i < len(lines):
        cells = _split_md_cells(lines[i])
        if cells and i + 1 < len(lines) and _is_separator(lines[i + 1]):
            headers = cells
            rows: list[list[str]] = []
            i += 2
            while i < len(lines):
                row = _split_md_cells(lines[i])
                if not row:
                    break
                if _is_separator(lines[i]):
                    i += 1
                    continue
                while len(row) < len(headers):
                    row.append("")
                rows.append(row[: max(len(headers), len(row))])
                i += 1
            if rows:
                title = "Смета"
                for back in range(1, 4):
                    idx = i - len(rows) - 2 - back
                    if idx >= 0:
                        prev = lines[idx].strip().lstrip("#").strip()
                        if prev and "|" not in prev:
                            title = prev[:120]
                            break
                tables.append(
                    EstimateTable(
                        title=title,
                        headers=headers,
                        rows=rows,
                        source_text=text,
                    )
                )
            continue
        i += 1
    return tables


def parse_plain_estimate_lines(text: str) -> EstimateTable | None:
    """Запасной разбор нумерованных позиций без markdown-таблицы."""
    rows: list[list[str]] = []
    pattern = re.compile(
        r"^\s*(?:\d+[.)]|[-•])\s+(.+?)(?:\s+[—\-–]\s+|\s{2,}|;\s*)"
        r"([\d\s]+(?:[.,]\d+)?)\s*"
        r"(м2|м²|м3|м³|м\.п\.|мп|шт\.?|компл\.?|кг|т|час|чел[.-]?час)?"
        r"(?:\s*[×x*]\s*([\d\s]+(?:[.,]\d+)?))?"
        r"(?:\s*=\s*([\d\s]+(?:[.,]\d+)?))?",
        re.IGNORECASE,
    )
    for line in text.splitlines():
        m = pattern.match(line)
        if not m:
            continue
        name, qty, unit, price, total = m.groups()
        rows.append(
            [
                str(len(rows) + 1),
                name.strip(),
                (unit or "").strip(),
                (qty or "").replace(" ", "").strip(),
                (price or "").replace(" ", "").strip(),
                (total or "").replace(" ", "").strip(),
                "",
            ]
        )
    if not rows:
        return None
    return EstimateTable(headers=list(DEFAULT_HEADERS), rows=rows, source_text=text)


def extract_estimate_from_text(text: str) -> EstimateTable | None:
    text = (text or "").strip()
    if not text:
        return None

    tables = parse_markdown_tables(text)
    if tables:
        # Берём самую «сметную» таблицу: больше строк + подходящие заголовки
        def score(t: EstimateTable) -> tuple[int, int]:
            header_bonus = 2 if _looks_like_header(t.headers) else 0
            return (header_bonus, len(t.rows))

        best = max(tables, key=score)
        notes = []
        for line in text.splitlines():
            if _TOTAL_HINT.search(line) and "|" not in line:
                notes.append(line.strip())
        best.notes = notes[-3:]
        return best

    return parse_plain_estimate_lines(text)


def extract_estimate_from_messages(messages: list[dict[str, str]]) -> EstimateTable | None:
    assistant = [m["content"] for m in messages if m.get("role") == "assistant" and m.get("content")]
    if not assistant:
        return None

    # Сначала последний ответ, затем объединение последних нескольких
    for content in reversed(assistant):
        table = extract_estimate_from_text(content)
        if table and table.has_data:
            return table

    merged = "\n\n".join(assistant[-3:])
    return extract_estimate_from_text(merged)


def looks_like_estimate(text: str) -> bool:
    table = extract_estimate_from_text(text)
    if table and table.has_data:
        return True
    lower = (text or "").lower()
    return ("| наименование" in lower or "| №" in lower) and "|" in text


def _autosize(ws) -> None:
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        width = 10
        for cell in col:
            value = "" if cell.value is None else str(cell.value)
            width = max(width, min(len(value) + 2, 60))
        ws.column_dimensions[letter].width = width


def export_xlsx(path: Path, table: EstimateTable, *, currency: str = "руб.") -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Смета"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="1A5FB4")
    thin = Border(
        left=Side(style="thin", color="CCCCCC"),
        right=Side(style="thin", color="CCCCCC"),
        top=Side(style="thin", color="CCCCCC"),
        bottom=Side(style="thin", color="CCCCCC"),
    )
    money_fill = PatternFill("solid", fgColor="FFF4CC")

    ws["A1"] = table.title
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(len(table.headers), 1))

    ws["A2"] = f"Дата выгрузки: {datetime.now():%d.%m.%Y %H:%M}  ·  Валюта: {currency}"
    ws["A2"].font = Font(color="666666", size=10)

    start = 4
    for col, header in enumerate(table.headers, start=1):
        cell = ws.cell(row=start, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        cell.border = thin

    for r_idx, row in enumerate(table.rows, start=start + 1):
        for c_idx, value in enumerate(row, start=1):
            cell = ws.cell(row=r_idx, column=c_idx, value=_cell_value(value))
            cell.border = thin
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            header = table.headers[c_idx - 1].lower() if c_idx - 1 < len(table.headers) else ""
            if any(k in header for k in ("сумм", "цена", "стоим")):
                cell.fill = money_fill

    notes_row = start + 1 + len(table.rows) + 1
    if table.notes:
        ws.cell(row=notes_row, column=1, value="Примечания:").font = Font(bold=True)
        for offset, note in enumerate(table.notes):
            ws.cell(row=notes_row + 1 + offset, column=1, value=note)

    footer = notes_row + len(table.notes) + 2
    ws.cell(
        row=footer,
        column=1,
        value="Сформировано в приложении «Помощник сметчика». Перед передачей заказчику проверьте цифры.",
    ).font = Font(italic=True, color="888888", size=9)

    _autosize(ws)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path


def export_csv(path: Path, table: EstimateTable) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, delimiter=";")
        writer.writerow(table.headers)
        writer.writerows(table.rows)
        for note in table.notes:
            writer.writerow([note])
    return path


def export_docx(path: Path, table: EstimateTable, *, currency: str = "руб.") -> Path:
    doc = Document()
    title = doc.add_heading(table.title, level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph(f"Дата выгрузки: {datetime.now():%d.%m.%Y %H:%M}")
    doc.add_paragraph(f"Валюта: {currency}")

    cols = max(len(table.headers), 1)
    tbl = doc.add_table(rows=1 + len(table.rows), cols=cols)
    tbl.style = "Table Grid"
    for i, header in enumerate(table.headers):
        tbl.rows[0].cells[i].text = header
    for r_idx, row in enumerate(table.rows):
        for c_idx in range(cols):
            value = row[c_idx] if c_idx < len(row) else ""
            tbl.rows[r_idx + 1].cells[c_idx].text = str(value)

    if table.notes:
        doc.add_paragraph("")
        doc.add_heading("Примечания", level=2)
        for note in table.notes:
            doc.add_paragraph(note)

    doc.add_paragraph(
        "Сформировано в приложении «Помощник сметчика». Перед передачей заказчику проверьте цифры."
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)
    return path


def export_markdown(path: Path, table: EstimateTable) -> Path:
    lines = [
        f"# {table.title}",
        "",
        f"_Дата: {datetime.now():%d.%m.%Y %H:%M}_",
        "",
        "| " + " | ".join(table.headers) + " |",
        "| " + " | ".join("---" for _ in table.headers) + " |",
    ]
    for row in table.rows:
        padded = list(row) + [""] * max(0, len(table.headers) - len(row))
        lines.append("| " + " | ".join(padded[: len(table.headers)]) + " |")
    if table.notes:
        lines.extend(["", "## Примечания", ""])
        lines.extend(f"- {n}" for n in table.notes)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def export_estimate(
    path: Path,
    table: EstimateTable,
    *,
    currency: str = "руб.",
) -> Path:
    suffix = path.suffix.lower()
    if suffix == ".xlsx":
        return export_xlsx(path, table, currency=currency)
    if suffix == ".csv":
        return export_csv(path, table)
    if suffix == ".docx":
        return export_docx(path, table, currency=currency)
    if suffix in {".md", ".markdown", ".txt"}:
        return export_markdown(path, table)
    raise ValueError(f"Неподдерживаемый формат: {suffix}")


def _cell_value(raw: str):
    text = str(raw or "").strip()
    if not text:
        return ""
    normalized = text.replace(" ", "").replace("\u00a0", "").replace(",", ".")
    if re.fullmatch(r"-?\d+(\.\d+)?", normalized):
        try:
            if "." in normalized:
                return float(normalized)
            return int(normalized)
        except ValueError:
            return text
    return text
