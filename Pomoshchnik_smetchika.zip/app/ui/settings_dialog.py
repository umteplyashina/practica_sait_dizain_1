"""Диалог настроек API и приложения."""

import customtkinter as ctk
from tkinter import filedialog, messagebox

from app.services.ai_client import AIClient
from app.services.llama_server import LlamaServerManager
from app.utils.config import DEFAULT_ENABLED_ASSISTANTS, DEFAULT_SECURITY, SettingsManager
from app.utils.constants import (
    API_PROVIDERS,
    AVAILABLE_MODELS,
    DEFAULT_LLAMA_MODEL,
    ENV_FILE,
    LLAMA_DIR,
    MODELS_DIR,
    NORMATIVE_BASES,
    WORK_MODES,
)
from app.utils.env_store import mask_api_key


class SettingsDialog(ctk.CTkToplevel):
    def __init__(self, parent, settings: SettingsManager, on_save=None):
        super().__init__(parent)
        self.settings = settings
        self.on_save = on_save
        self.ai_client = AIClient(settings)
        self.llama_server = LlamaServerManager(settings)
        self._loading = False
        self._key_visible = False
        self.assistant_switches: dict[str, ctk.CTkSwitch] = {}

        self.title("Настройки")
        self.geometry("580x920")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self._build_ui()
        self._load_values()

    def _build_ui(self) -> None:
        frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(
            frame, text="Провайдер", font=ctk.CTkFont(size=18, weight="bold")
        ).pack(anchor="w", pady=(0, 10))

        ctk.CTkLabel(frame, text="Провайдер AI:").pack(anchor="w")
        provider_names = [p["title"] for p in API_PROVIDERS.values()]
        self.provider_keys = list(API_PROVIDERS.keys())
        self.provider_combo = ctk.CTkComboBox(
            frame, width=520, values=provider_names, command=self._on_provider_change
        )
        self.provider_combo.pack(anchor="w", pady=(2, 4))

        self.none_hint = ctk.CTkLabel(
            frame,
            text="Режим «Без помощника»: AI отключён, запросы к модели не отправляются.",
            font=ctk.CTkFont(size=11),
            text_color="#FFAA66",
            wraplength=500,
            justify="left",
        )

        self.llama_hint = ctk.CTkLabel(
            frame,
            text=(
                "Локальный режим: модель работает на вашем ПК через llama.cpp.\n"
                f"• llama-server.exe → {LLAMA_DIR.name}/\n"
                f"• модель .gguf → {MODELS_DIR.name}/ ({DEFAULT_LLAMA_MODEL})"
            ),
            font=ctk.CTkFont(size=11),
            text_color="#66CC88",
            wraplength=500,
            justify="left",
        )

        self.llama_frame = ctk.CTkFrame(frame, fg_color=("gray90", "gray20"))

        ctk.CTkLabel(self.llama_frame, text="Путь к модели (.gguf):").pack(
            anchor="w", padx=12, pady=(10, 0)
        )
        model_row = ctk.CTkFrame(self.llama_frame, fg_color="transparent")
        model_row.pack(fill="x", padx=12, pady=(2, 4))
        self.llama_model_entry = ctk.CTkEntry(model_row, width=380)
        self.llama_model_entry.pack(side="left")
        ctk.CTkButton(
            model_row, text="Обзор…", width=90, command=self._browse_model
        ).pack(side="left", padx=(8, 0))

        ctk.CTkLabel(self.llama_frame, text="llama-server.exe (необязательно):").pack(
            anchor="w", padx=12, pady=(4, 0)
        )
        exe_row = ctk.CTkFrame(self.llama_frame, fg_color="transparent")
        exe_row.pack(fill="x", padx=12, pady=(2, 4))
        self.llama_exe_entry = ctk.CTkEntry(
            exe_row, width=380, placeholder_text="Автопоиск в llama.cpp/"
        )
        self.llama_exe_entry.pack(side="left")
        ctk.CTkButton(
            exe_row, text="Обзор…", width=90, command=self._browse_server_exe
        ).pack(side="left", padx=(8, 0))

        params_row = ctk.CTkFrame(self.llama_frame, fg_color="transparent")
        params_row.pack(fill="x", padx=12, pady=(4, 4))
        ctk.CTkLabel(params_row, text="Порт:").pack(side="left")
        self.llama_port_entry = ctk.CTkEntry(params_row, width=70)
        self.llama_port_entry.pack(side="left", padx=(4, 12))
        ctk.CTkLabel(params_row, text="Контекст:").pack(side="left")
        self.llama_context_entry = ctk.CTkEntry(params_row, width=80)
        self.llama_context_entry.pack(side="left", padx=(4, 12))
        ctk.CTkLabel(params_row, text="GPU слои (-1 = все):").pack(side="left")
        self.llama_gpu_entry = ctk.CTkEntry(params_row, width=60)
        self.llama_gpu_entry.pack(side="left", padx=(4, 0))

        self.llama_autostart_switch = ctk.CTkSwitch(
            self.llama_frame,
            text="Запускать llama-server при старте приложения",
            onvalue=True,
            offvalue=False,
        )
        self.llama_autostart_switch.pack(anchor="w", padx=12, pady=(4, 4))

        llama_btns = ctk.CTkFrame(self.llama_frame, fg_color="transparent")
        llama_btns.pack(fill="x", padx=12, pady=(4, 10))
        ctk.CTkButton(
            llama_btns,
            text="Запустить сервер",
            width=150,
            command=self._start_llama_server,
        ).pack(side="left")
        ctk.CTkButton(
            llama_btns,
            text="Остановить",
            width=120,
            fg_color="gray40",
            command=self._stop_llama_server,
        ).pack(side="left", padx=(8, 0))
        self.llama_status_label = ctk.CTkLabel(
            self.llama_frame,
            text="",
            font=ctk.CTkFont(size=11),
            text_color="gray",
            wraplength=480,
            justify="left",
        )
        self.llama_status_label.pack(anchor="w", padx=12, pady=(0, 10))

        self.api_key_label = ctk.CTkLabel(frame, text="API-ключ (хранится в .env):")
        self.api_key_label.pack(anchor="w")
        key_row = ctk.CTkFrame(frame, fg_color="transparent")
        key_row.pack(fill="x", pady=(2, 4))

        self.api_key_entry = ctk.CTkEntry(
            key_row, width=400, show="*", placeholder_text="sk-..."
        )
        self.api_key_entry.pack(side="left")

        self.show_key_btn = ctk.CTkButton(
            key_row, text="Показать", width=100, command=self._toggle_key_visibility
        )
        self.show_key_btn.pack(side="left", padx=(8, 0))

        ctk.CTkLabel(
            frame,
            text=f"Файл секретов: {ENV_FILE.name}  ·  ключ не сохраняется в settings.json",
            font=ctk.CTkFont(size=11),
            text_color="gray",
            wraplength=500,
            justify="left",
        ).pack(anchor="w", pady=(0, 10))

        self.api_url_label = ctk.CTkLabel(frame, text="URL API (OpenAI-совместимый):")
        self.api_url_label.pack(anchor="w")
        self.api_url_entry = ctk.CTkEntry(frame, width=520)
        self.api_url_entry.pack(anchor="w", pady=(2, 4))

        self.api_url_hint = ctk.CTkLabel(
            frame,
            text=(
                "Если api.openai.com недоступен в вашем регионе — укажите URL "
                "совместимого провайдера (шлюз, OpenRouter, Azure и т.д.)."
            ),
            font=ctk.CTkFont(size=11),
            text_color="#FFAA66",
            wraplength=500,
            justify="left",
        )

        self.model_label = ctk.CTkLabel(frame, text="Модель:")
        self.model_label.pack(anchor="w")
        self.model_combo = ctk.CTkComboBox(frame, width=520, values=AVAILABLE_MODELS)
        self.model_combo.pack(anchor="w", pady=(2, 10))

        ctk.CTkLabel(frame, text="Температура (0.0 — 1.0):").pack(anchor="w")
        self.temp_slider = ctk.CTkSlider(frame, from_=0, to=1, number_of_steps=10)
        self.temp_slider.pack(anchor="w", pady=(2, 2))
        self.temp_label = ctk.CTkLabel(frame, text="0.3")
        self.temp_label.pack(anchor="w", pady=(0, 10))
        self.temp_slider.configure(
            command=lambda v: self.temp_label.configure(text=f"{float(v):.1f}")
        )

        ctk.CTkLabel(
            frame, text="Безопасность", font=ctk.CTkFont(size=18, weight="bold")
        ).pack(anchor="w", pady=(10, 4))
        ctk.CTkLabel(
            frame,
            text="API-ключ всегда пишется только в .env. Ниже — дополнительные защиты.",
            font=ctk.CTkFont(size=11),
            text_color="gray",
            wraplength=500,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        security_frame = ctk.CTkFrame(frame, fg_color=("gray90", "gray20"))
        security_frame.pack(fill="x", pady=(0, 8))

        self.mask_key_switch = ctk.CTkSwitch(
            security_frame,
            text="Маскировать API-ключ в поле ввода",
            onvalue=True,
            offvalue=False,
        )
        self.mask_key_switch.pack(anchor="w", padx=12, pady=(10, 4))

        self.confirm_show_switch = ctk.CTkSwitch(
            security_frame,
            text="Спрашивать подтверждение перед показом ключа",
            onvalue=True,
            offvalue=False,
        )
        self.confirm_show_switch.pack(anchor="w", padx=12, pady=4)

        self.protect_env_switch = ctk.CTkSwitch(
            security_frame,
            text="Ограничивать доступ к файлу .env (права пользователя)",
            onvalue=True,
            offvalue=False,
        )
        self.protect_env_switch.pack(anchor="w", padx=12, pady=(4, 10))

        sec_btns = ctk.CTkFrame(frame, fg_color="transparent")
        sec_btns.pack(fill="x", pady=(0, 10))
        ctk.CTkButton(
            sec_btns,
            text="Очистить API-ключ",
            width=180,
            fg_color="#AA4444",
            hover_color="#883333",
            command=self._clear_api_key,
        ).pack(side="left")
        ctk.CTkButton(
            sec_btns,
            text="Статус ключа",
            width=140,
            fg_color="gray40",
            command=self._show_key_status,
        ).pack(side="left", padx=(8, 0))

        ctk.CTkLabel(
            frame, text="Помощники", font=ctk.CTkFont(size=18, weight="bold")
        ).pack(anchor="w", pady=(10, 4))
        ctk.CTkLabel(
            frame,
            text="Отключите ненужные режимы — они скроются с боковой панели.",
            font=ctk.CTkFont(size=11),
            text_color="gray",
            wraplength=500,
            justify="left",
        ).pack(anchor="w", pady=(0, 8))

        assistants_frame = ctk.CTkFrame(frame, fg_color=("gray90", "gray20"))
        assistants_frame.pack(fill="x", pady=(0, 10))

        for mode_id, mode in WORK_MODES.items():
            row = ctk.CTkFrame(assistants_frame, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=4)
            switch = ctk.CTkSwitch(
                row,
                text=f"{mode['icon']}  {mode['title']}",
                onvalue=True,
                offvalue=False,
            )
            switch.pack(anchor="w")
            self.assistant_switches[mode_id] = switch

        toggle_row = ctk.CTkFrame(frame, fg_color="transparent")
        toggle_row.pack(fill="x", pady=(0, 10))
        ctk.CTkButton(
            toggle_row, text="Включить все", width=140, command=self._enable_all_assistants
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            toggle_row,
            text="Отключить все",
            width=140,
            fg_color="gray40",
            command=self._disable_all_assistants,
        ).pack(side="left")

        ctk.CTkLabel(
            frame, text="Сметные настройки", font=ctk.CTkFont(size=18, weight="bold")
        ).pack(anchor="w", pady=(10, 10))

        ctk.CTkLabel(frame, text="Нормативная база:").pack(anchor="w")
        self.normative_combo = ctk.CTkComboBox(frame, width=520, values=NORMATIVE_BASES)
        self.normative_combo.pack(anchor="w", pady=(2, 10))

        ctk.CTkLabel(frame, text="Валюта:").pack(anchor="w")
        self.currency_entry = ctk.CTkEntry(frame, width=520)
        self.currency_entry.pack(anchor="w", pady=(2, 10))

        ctk.CTkLabel(frame, text="Тема интерфейса:").pack(anchor="w")
        self.theme_combo = ctk.CTkComboBox(
            frame, width=520, values=["dark", "light", "system"]
        )
        self.theme_combo.pack(anchor="w", pady=(2, 10))

        btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
        btn_frame.pack(fill="x", pady=(20, 0))

        ctk.CTkButton(
            btn_frame, text="Проверить подключение", command=self._test_connection, width=200
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            btn_frame, text="Сохранить", command=self._save, width=120
        ).pack(side="right")

    def _enable_all_assistants(self) -> None:
        for switch in self.assistant_switches.values():
            switch.select()

    def _disable_all_assistants(self) -> None:
        for mode_id, switch in self.assistant_switches.items():
            if mode_id == "free":
                switch.select()
            else:
                switch.deselect()

    def _browse_model(self) -> None:
        path = filedialog.askopenfilename(
            parent=self,
            title="Выберите файл модели",
            filetypes=[("GGUF модели", "*.gguf"), ("Все файлы", "*.*")],
            initialdir=str(MODELS_DIR if MODELS_DIR.exists() else "."),
        )
        if path:
            self.llama_model_entry.delete(0, "end")
            self.llama_model_entry.insert(0, path)

    def _browse_server_exe(self) -> None:
        path = filedialog.askopenfilename(
            parent=self,
            title="Выберите llama-server.exe",
            filetypes=[("llama-server", "llama-server.exe"), ("EXE", "*.exe")],
            initialdir=str(LLAMA_DIR if LLAMA_DIR.exists() else "."),
        )
        if path:
            self.llama_exe_entry.delete(0, "end")
            self.llama_exe_entry.insert(0, path)

    def _collect_llama_settings(self) -> dict:
        try:
            port = int(self.llama_port_entry.get().strip() or "8080")
        except ValueError:
            port = 8080
        try:
            context = int(self.llama_context_entry.get().strip() or "8192")
        except ValueError:
            context = 8192
        try:
            gpu_layers = int(self.llama_gpu_entry.get().strip() or "-1")
        except ValueError:
            gpu_layers = -1
        return {
            "llama_model_path": self.llama_model_entry.get().strip(),
            "llama_server_exe": self.llama_exe_entry.get().strip(),
            "llama_port": port,
            "llama_context_size": context,
            "llama_gpu_layers": gpu_layers,
            "llama_autostart": bool(self.llama_autostart_switch.get()),
        }

    def _refresh_llama_status(self) -> None:
        self.llama_server = LlamaServerManager(self.settings)
        self.llama_status_label.configure(text=self.llama_server.status_message())

    def _start_llama_server(self) -> None:
        self._apply_to_settings()
        self.llama_server = LlamaServerManager(self.settings)
        self.ai_client.reset_client()
        ok, msg = self.llama_server.start()
        self._refresh_llama_status()
        if ok:
            messagebox.showinfo("Llama.cpp", msg, parent=self)
        else:
            messagebox.showerror("Llama.cpp", msg, parent=self)

    def _stop_llama_server(self) -> None:
        self.llama_server.stop()
        self.ai_client.reset_client()
        self._refresh_llama_status()
        messagebox.showinfo("Llama.cpp", "Локальный сервер остановлен.", parent=self)

    def _provider_index(self) -> int:
        current = self.provider_combo.get()
        titles = [p["title"] for p in API_PROVIDERS.values()]
        try:
            return titles.index(current)
        except ValueError:
            return 0

    def _current_provider_key(self) -> str:
        return self.provider_keys[self._provider_index()]

    def _on_provider_change(self, _choice: str) -> None:
        if self._loading:
            return
        key = self._current_provider_key()
        preset = API_PROVIDERS[key]
        self.api_url_entry.delete(0, "end")
        if preset["url"]:
            self.api_url_entry.insert(0, preset["url"])
        if key == "llama_cpp":
            self.model_combo.configure(values=[preset["model"]])
            self.model_combo.set(preset["model"])
        else:
            self.model_combo.configure(values=AVAILABLE_MODELS)
            if preset["model"]:
                self.model_combo.set(preset["model"])
        self._update_provider_ui(key)

    def _update_provider_ui(self, provider_key: str) -> None:
        self.none_hint.pack_forget()
        self.llama_hint.pack_forget()
        self.llama_frame.pack_forget()
        self.api_url_hint.pack_forget()

        if provider_key == "none":
            self.none_hint.pack(anchor="w", pady=(0, 8))
            self.api_key_entry.configure(state="disabled")
            self.api_url_entry.configure(state="disabled")
            self.model_combo.configure(state="disabled")
            self.temp_slider.configure(state="disabled")
            self.show_key_btn.configure(state="disabled")
        elif provider_key == "llama_cpp":
            self.llama_hint.pack(anchor="w", pady=(0, 8))
            self.llama_frame.pack(fill="x", pady=(0, 8))
            self.api_key_entry.configure(state="disabled")
            self.api_url_entry.configure(state="disabled")
            self.model_combo.configure(state="normal")
            self.temp_slider.configure(state="normal")
            self.show_key_btn.configure(state="disabled")
            self._refresh_llama_status()
        else:
            self.api_url_hint.pack(anchor="w", pady=(0, 10))
            self.api_key_entry.configure(state="normal")
            self.api_url_entry.configure(state="normal")
            self.model_combo.configure(state="normal")
            self.temp_slider.configure(state="normal")
            self.show_key_btn.configure(state="normal")

    def _apply_key_mask(self) -> None:
        if self._key_visible:
            self.api_key_entry.configure(show="")
            self.show_key_btn.configure(text="Скрыть")
        else:
            show = "*" if bool(self.mask_key_switch.get()) else ""
            self.api_key_entry.configure(show=show)
            self.show_key_btn.configure(text="Показать")

    def _toggle_key_visibility(self) -> None:
        if not self._key_visible and bool(self.confirm_show_switch.get()):
            key = self.api_key_entry.get().strip()
            if key and not messagebox.askyesno(
                "Безопасность",
                "Показать API-ключ на экране?\n\n"
                "Убедитесь, что экран не видят посторонние.",
                parent=self,
            ):
                return
        self._key_visible = not self._key_visible
        self._apply_key_mask()

    def _clear_api_key(self) -> None:
        if not messagebox.askyesno(
            "Очистить ключ",
            "Удалить API-ключ из .env и памяти приложения?",
            parent=self,
        ):
            return
        self.api_key_entry.delete(0, "end")
        self.settings.clear_api_key()
        self._key_visible = False
        self._apply_key_mask()
        messagebox.showinfo("Безопасность", "API-ключ очищен.", parent=self)

    def _show_key_status(self) -> None:
        key = self.api_key_entry.get().strip() or self.settings.get("api_key", "")
        if not key:
            messagebox.showinfo(
                "Статус ключа",
                f"Ключ не задан.\nФайл: {ENV_FILE}",
                parent=self,
            )
            return
        messagebox.showinfo(
            "Статус ключа",
            f"Ключ задан: {mask_api_key(key)}\n"
            f"Длина: {len(key)} символов\n"
            f"Хранение: {ENV_FILE}\n"
            "settings.json ключ не содержит.",
            parent=self,
        )

    def _test_connection(self) -> None:
        if self._current_provider_key() == "none":
            messagebox.showinfo(
                "Подключение",
                "Выбран режим «Без помощника». Проверка API не требуется.",
                parent=self,
            )
            return
        self._apply_to_settings()
        self.ai_client.reset_client()
        ok, msg = self.ai_client.test_connection()
        if ok:
            messagebox.showinfo("Подключение", msg, parent=self)
        else:
            messagebox.showerror("Ошибка", msg, parent=self)

    def _apply_to_settings(self) -> None:
        provider_key = self._current_provider_key()
        preset = API_PROVIDERS[provider_key]
        url = self.api_url_entry.get().strip() or preset["url"]
        model = self.model_combo.get() or preset["model"]
        data = {
            "provider": provider_key,
            "api_key": self.api_key_entry.get().strip(),
            "api_base_url": url,
            "model": model,
            "temperature": round(self.temp_slider.get(), 1),
            "normative_base": self.normative_combo.get(),
            "currency": self.currency_entry.get().strip() or "руб.",
            "theme": self.theme_combo.get(),
            "enabled_assistants": self._collect_assistants(),
            "security": {
                "mask_api_key": bool(self.mask_key_switch.get()),
                "confirm_show_key": bool(self.confirm_show_switch.get()),
                "protect_env_file": bool(self.protect_env_switch.get()),
            },
        }
        if provider_key == "llama_cpp":
            data.update(self._collect_llama_settings())
            data["api_base_url"] = f"http://127.0.0.1:{data['llama_port']}/v1"
        self.settings.update(data)

    def _load_values(self) -> None:
        self._loading = True
        s = self.settings.all
        provider_key = s.get("provider", "openai")
        if provider_key not in API_PROVIDERS:
            provider_key = "openai"

        self.provider_combo.set(API_PROVIDERS[provider_key]["title"])

        self.api_key_entry.insert(0, s.get("api_key", ""))
        self.api_url_entry.insert(0, s.get("api_base_url", API_PROVIDERS[provider_key]["url"]))

        self.model_combo.configure(values=AVAILABLE_MODELS)
        saved_model = s.get("model") or API_PROVIDERS[provider_key]["model"]
        if provider_key == "llama_cpp":
            self.model_combo.configure(values=[saved_model or API_PROVIDERS["llama_cpp"]["model"]])
        if saved_model:
            self.model_combo.set(saved_model)
        elif AVAILABLE_MODELS:
            self.model_combo.set(AVAILABLE_MODELS[0])

        self.temp_slider.set(float(s.get("temperature", 0.3)))
        self.temp_label.configure(text=f"{float(s.get('temperature', 0.3)):.1f}")

        security = s.get("security", DEFAULT_SECURITY)
        if not isinstance(security, dict):
            security = DEFAULT_SECURITY
        if security.get("mask_api_key", True):
            self.mask_key_switch.select()
        else:
            self.mask_key_switch.deselect()
        if security.get("confirm_show_key", True):
            self.confirm_show_switch.select()
        else:
            self.confirm_show_switch.deselect()
        if security.get("protect_env_file", True):
            self.protect_env_switch.select()
        else:
            self.protect_env_switch.deselect()

        self._key_visible = False
        self._apply_key_mask()
        self.mask_key_switch.configure(command=self._on_mask_switch)

        normative = s.get("normative_base", "") or "Не указана"
        if normative not in NORMATIVE_BASES:
            normative = "Другая"
        self.normative_combo.set(normative)

        self.currency_entry.insert(0, s.get("currency", "руб."))
        self.theme_combo.set(s.get("theme", "dark"))

        self.llama_model_entry.insert(
            0, s.get("llama_model_path", f"models/{DEFAULT_LLAMA_MODEL}")
        )
        self.llama_exe_entry.insert(0, s.get("llama_server_exe", ""))
        self.llama_port_entry.insert(0, str(s.get("llama_port", 8080)))
        self.llama_context_entry.insert(0, str(s.get("llama_context_size", 8192)))
        self.llama_gpu_entry.insert(0, str(s.get("llama_gpu_layers", -1)))
        if s.get("llama_autostart", True):
            self.llama_autostart_switch.select()
        else:
            self.llama_autostart_switch.deselect()

        assistants = s.get("enabled_assistants", DEFAULT_ENABLED_ASSISTANTS)
        if not isinstance(assistants, dict):
            assistants = DEFAULT_ENABLED_ASSISTANTS
        for mode_id, switch in self.assistant_switches.items():
            if assistants.get(mode_id, True):
                switch.select()
            else:
                switch.deselect()

        self._update_provider_ui(provider_key)
        self._loading = False

    def _on_mask_switch(self) -> None:
        if not self._key_visible:
            self._apply_key_mask()

    def _collect_assistants(self) -> dict[str, bool]:
        enabled = {
            mode_id: bool(switch.get())
            for mode_id, switch in self.assistant_switches.items()
        }
        if not any(enabled.values()):
            enabled["free"] = True
            messagebox.showwarning(
                "Помощники",
                "Должен остаться хотя бы один помощник.\n"
                "Оставлен включённым «Свободный диалог».",
                parent=self,
            )
            self.assistant_switches["free"].select()
        return enabled

    def _save(self) -> None:
        self._apply_to_settings()
        self.settings.save()
        self.ai_client.reset_client()

        theme = self.settings.get("theme", "dark")
        ctk.set_appearance_mode(theme)

        if self.on_save:
            self.on_save()

        messagebox.showinfo(
            "Настройки",
            "Настройки сохранены.\n"
            f"API-ключ записан в {ENV_FILE.name}.",
            parent=self,
        )
        self.destroy()
