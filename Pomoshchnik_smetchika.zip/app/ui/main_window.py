"""Главное окно приложения «Помощник сметчика»."""

import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk

from app.services.ai_client import AIClient
from app.services.document_parser import DocumentParser
from app.services.estimate_exporter import (
    export_estimate,
    extract_estimate_from_messages,
    looks_like_estimate,
)
from app.services.session_store import ChatSession, SessionStore
from app.ui.sessions_dialog import SessionsDialog
from app.ui.settings_dialog import SettingsDialog
from app.utils.config import SettingsManager
from app.utils.constants import APP_NAME, APP_VERSION, SUPPORTED_EXTENSIONS, WORK_MODES

UI_FLUSH_INTERVAL_MS = 80


class MainWindow(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()

        self.settings = SettingsManager()
        self.ai_client = AIClient(self.settings)
        self.session_store = SessionStore()
        self.current_session = ChatSession.create()
        self.messages: list[dict[str, str]] = []
        self.attached_files: list[dict[str, str]] = []
        self.current_mode = "free"
        self.is_generating = False
        self.is_loading_files = False
        self._cancel_event = threading.Event()
        self._chunk_buffer = ""
        self._flush_scheduled = False

        self._setup_window()
        self._build_ui()
        self._update_status_bar()

        restored = self._restore_last_session()
        if not restored:
            self._show_welcome()

        if not self.settings.is_configured and not self.settings.is_assistant_off:
            self.after(500, self._open_settings)

        if (
            self.settings.get("provider") == "llama_cpp"
            and self.settings.get("llama_autostart", True)
        ):
            self.after(800, self._autostart_llama)

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _setup_window(self) -> None:
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1200x800")
        self.minsize(900, 600)

        theme = self.settings.get("theme", "dark")
        ctk.set_appearance_mode(theme)
        ctk.set_default_color_theme("blue")

    def _build_ui(self) -> None:
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_chat_area()
        self._build_input_area()

    def _build_sidebar(self) -> None:
        sidebar = ctk.CTkFrame(self, width=260, corner_radius=0)
        sidebar.grid(row=0, column=0, rowspan=2, sticky="nsew")
        sidebar.grid_propagate(False)

        ctk.CTkLabel(
            sidebar,
            text="🏗️ " + APP_NAME,
            font=ctk.CTkFont(size=20, weight="bold"),
        ).pack(padx=15, pady=(20, 5), anchor="w")

        ctk.CTkLabel(
            sidebar,
            text="Цифровой второй сметчик",
            font=ctk.CTkFont(size=12),
            text_color="gray",
        ).pack(padx=15, pady=(0, 20), anchor="w")

        ctk.CTkLabel(
            sidebar, text="Режимы работы", font=ctk.CTkFont(size=14, weight="bold")
        ).pack(padx=15, pady=(0, 8), anchor="w")

        self.modes_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        self.modes_frame.pack(fill="x", padx=0, pady=0)

        self.mode_buttons: dict[str, ctk.CTkButton] = {}
        for mode_id, mode in WORK_MODES.items():
            btn = ctk.CTkButton(
                self.modes_frame,
                text=f"{mode['icon']}  {mode['title']}",
                anchor="w",
                fg_color="transparent",
                text_color=("gray10", "gray90"),
                hover_color=("gray85", "gray25"),
                command=lambda m=mode_id: self._set_mode(m),
            )
            btn.pack(fill="x", padx=10, pady=2)
            self.mode_buttons[mode_id] = btn

        self._apply_assistant_visibility()
        enabled = self.settings.enabled_assistant_ids()
        start_mode = "free" if "free" in enabled else (enabled[0] if enabled else "free")
        self.current_mode = start_mode
        self._highlight_mode(start_mode)

        ctk.CTkFrame(sidebar, height=2, fg_color="gray30").pack(fill="x", padx=15, pady=20)

        ctk.CTkButton(
            sidebar, text="📎 Загрузить документ", command=self._attach_file
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="🗑️ Новый диалог", command=self._new_chat, fg_color="gray30"
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="📁 Мои сметы", command=self._open_sessions, fg_color="#2B7A4B"
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="📤 Выгрузить смету", command=self._export_estimate, fg_color="#1A5FB4"
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="💾 Экспорт диалога", command=self._export_chat, fg_color="gray30"
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="📋 Копировать диалог", command=self._copy_entire_chat, fg_color="gray30"
        ).pack(fill="x", padx=10, pady=3)

        ctk.CTkButton(
            sidebar, text="⚙️ Настройки", command=self._open_settings, fg_color="gray30"
        ).pack(fill="x", padx=10, pady=3)

        self.status_label = ctk.CTkLabel(
            sidebar, text="", font=ctk.CTkFont(size=11), text_color="gray", wraplength=230
        )
        self.status_label.pack(side="bottom", padx=15, pady=15, anchor="w")

    def _build_chat_area(self) -> None:
        chat_frame = ctk.CTkFrame(self, fg_color="transparent")
        chat_frame.grid(row=0, column=1, sticky="nsew", padx=(0, 10), pady=(10, 5))
        chat_frame.grid_rowconfigure(0, weight=1)
        chat_frame.grid_columnconfigure(0, weight=1)

        self.chat_display = ctk.CTkTextbox(
            chat_frame,
            wrap="word",
            font=ctk.CTkFont(family="Segoe UI", size=14),
            activate_scrollbars=True,
        )
        self.chat_display.grid(row=0, column=0, sticky="nsew")
        self._setup_chat_copy_support()
        self._configure_chat_tags()

    def _setup_chat_copy_support(self) -> None:
        """Разрешает выделение и копирование, запрещает правку текста чата."""
        widget = self.chat_display
        widget.configure(state="normal")

        widget.bind("<Key>", self._on_chat_key)
        widget.bind("<Control-c>", self._copy_chat_selection)
        widget.bind("<Control-C>", self._copy_chat_selection)
        widget.bind("<Control-a>", self._select_all_chat)
        widget.bind("<Control-A>", self._select_all_chat)
        widget.bind("<Control-Insert>", self._copy_chat_selection)
        widget.bind("<<Copy>>", self._copy_chat_selection)
        widget.bind("<Button-3>", self._show_chat_context_menu)

        self._chat_menu = tk.Menu(self, tearoff=0)
        self._chat_menu.add_command(label="Копировать", command=self._copy_chat_selection)
        self._chat_menu.add_command(label="Выделить всё", command=self._select_all_chat)
        self._chat_menu.add_separator()
        self._chat_menu.add_command(
            label="Копировать весь диалог", command=self._copy_entire_chat
        )
        self._chat_menu.add_command(
            label="Копировать последний ответ", command=self._copy_last_assistant_reply
        )
        self._chat_menu.add_separator()
        self._chat_menu.add_command(
            label="Выгрузить смету в Excel…", command=self._export_estimate
        )

    def _on_chat_key(self, event: tk.Event) -> str | None:
        # Разрешаем только сочетания копирования / выделения
        if event.state & 0x4:  # Control
            key = (event.keysym or "").lower()
            if key in {"c", "a", "insert"}:
                return None
        return "break"

    def _show_chat_context_menu(self, event: tk.Event) -> None:
        try:
            self._chat_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._chat_menu.grab_release()

    def _get_chat_selection(self) -> str:
        try:
            return self.chat_display.get("sel.first", "sel.last")
        except tk.TclError:
            return ""

    def _copy_to_clipboard(self, text: str, *, notify: bool = True) -> bool:
        text = (text or "").strip("\n")
        if not text:
            if notify:
                messagebox.showinfo("Копирование", "Нет текста для копирования.")
            return False
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update()
        if notify:
            self.status_label.configure(text="Скопировано в буфер обмена")
            self.after(2500, lambda: self.status_label.configure(text=""))
        return True

    def _copy_chat_selection(self, _event: tk.Event | None = None) -> str:
        selected = self._get_chat_selection()
        if selected:
            self._copy_to_clipboard(selected)
        elif _event is None:
            messagebox.showinfo(
                "Копирование",
                "Сначала выделите текст в диалоге.\n"
                "Или используйте «Копировать весь диалог».",
            )
        return "break"

    def _select_all_chat(self, _event: tk.Event | None = None) -> str:
        self.chat_display.tag_add("sel", "1.0", "end-1c")
        self.chat_display.mark_set("insert", "1.0")
        self.chat_display.see("insert")
        return "break"

    def _copy_entire_chat(self) -> None:
        text = self.chat_display.get("1.0", "end-1c")
        self._copy_to_clipboard(text)

    def _copy_last_assistant_reply(self) -> None:
        for msg in reversed(self.messages):
            if msg.get("role") == "assistant" and (msg.get("content") or "").strip():
                self._copy_to_clipboard(msg["content"])
                return
        # Если ответ ещё стримится / не в истории — берём хвост чата
        text = self.chat_display.get("1.0", "end-1c")
        marker = "Помощник сметчика:"
        bot_marker = "ИИ-бот по сметам:"
        last = max(text.rfind(marker), text.rfind(bot_marker))
        if last >= 0:
            chunk = text[last:]
            # Убираем заголовок первой строки
            lines = chunk.splitlines()
            body = "\n".join(lines[1:]).strip() if len(lines) > 1 else chunk
            self._copy_to_clipboard(body)
            return
        messagebox.showinfo("Копирование", "Пока нет ответа помощника для копирования.")

    def _configure_chat_tags(self) -> None:
        theme = self.settings.get("theme", "dark")
        appearance = ctk.get_appearance_mode().lower()
        is_light = theme == "light" or (theme == "system" and appearance == "light")

        if is_light:
            colors = {
                "user": "#1A5FB4",
                "assistant": "#1C1C1C",
                "system": "#5E5E5E",
                "error": "#C01C28",
                "file": "#9C6B00",
                "bold": "#000000",
            }
        else:
            colors = {
                "user": "#4A9EFF",
                "assistant": "#E8E8E8",
                "system": "#A0A0A0",
                "error": "#FF6B6B",
                "file": "#FFD166",
                "bold": "#FFFFFF",
            }

        self.chat_display.configure(state="normal")
        for tag, color in colors.items():
            self.chat_display.tag_config(tag, foreground=color)

    def _build_input_area(self) -> None:
        input_frame = ctk.CTkFrame(self, fg_color="transparent")
        input_frame.grid(row=1, column=1, sticky="ew", padx=(0, 10), pady=(5, 10))
        input_frame.grid_columnconfigure(0, weight=1)

        self.files_label = ctk.CTkLabel(
            input_frame, text="", font=ctk.CTkFont(size=11), text_color="#FFD166", anchor="w"
        )
        self.files_label.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 5))

        self.input_box = ctk.CTkTextbox(
            input_frame,
            height=100,
            font=ctk.CTkFont(family="Segoe UI", size=14),
            wrap="word",
        )
        self.input_box.grid(row=1, column=0, sticky="ew", padx=(0, 10))
        self.input_box.bind("<Return>", self._on_input_return)
        self.input_box.bind("<Shift-Return>", lambda _e: None)

        btn_frame = ctk.CTkFrame(input_frame, fg_color="transparent")
        btn_frame.grid(row=1, column=1, sticky="ns")

        self.send_btn = ctk.CTkButton(
            btn_frame, text="Отправить\n(Enter)", width=130, command=self._send_message
        )
        self.send_btn.pack(pady=(0, 5))

        self.stop_btn = ctk.CTkButton(
            btn_frame,
            text="Стоп",
            width=130,
            fg_color="#CC3333",
            hover_color="#AA2222",
            command=self._stop_generation,
            state="disabled",
        )
        self.stop_btn.pack()

    def _apply_assistant_visibility(self) -> None:
        for mode_id, btn in self.mode_buttons.items():
            btn.pack_forget()

        for mode_id in WORK_MODES:
            btn = self.mode_buttons[mode_id]
            if self.settings.is_assistant_enabled(mode_id):
                btn.pack(fill="x", padx=10, pady=2)
                btn.configure(state="normal")

        if not self.settings.is_assistant_enabled(self.current_mode):
            enabled = self.settings.enabled_assistant_ids()
            fallback = "free" if "free" in enabled else (enabled[0] if enabled else "free")
            self.current_mode = fallback
            self._highlight_mode(fallback)

    def _highlight_mode(self, mode_id: str) -> None:
        for mid, btn in self.mode_buttons.items():
            if mid == mode_id:
                btn.configure(fg_color=("#3B8ED0", "#1F6AA5"))
            else:
                btn.configure(fg_color="transparent")

    def _set_mode(self, mode_id: str) -> None:
        if not self.settings.is_assistant_enabled(mode_id):
            messagebox.showwarning(
                "Помощник отключён",
                "Этот помощник отключён в настройках.",
            )
            return

        if self.is_generating or self.is_loading_files:
            messagebox.showwarning(
                "Подождите",
                "Дождитесь завершения текущей операции.",
            )
            return

        self.current_mode = mode_id
        self._highlight_mode(mode_id)
        mode = WORK_MODES[mode_id]
        self._append_system_message(f"Режим: {mode['title']}")

        if mode_id == "audit" and self.attached_files:
            self.after(300, self._auto_start_audit)

    def _auto_start_audit(self) -> None:
        if (
            self.current_mode != "audit"
            or not self.attached_files
            or self.is_generating
            or self.is_loading_files
        ):
            return
        self._append_system_message(
            "Запуск автоматической проверки прикреплённой сметы..."
        )
        self._send_message(auto_text="Проверь прикреплённую смету.")

    def _show_welcome(self) -> None:
        welcome = (
            f"Добро пожаловать в «{APP_NAME}»!\n\n"
            "Я — ваш цифровой помощник-сметчик. Могу помочь:\n"
            "  • составить и проверить смету (режим «ИИ-бот по сметам»)\n"
            "  • провести профессиональный аудит и подбор расценок\n"
            "  • анализировать объёмы работ\n"
            "  • находить ошибки и несоответствия\n"
            "  • объяснять сметные вопросы\n\n"
            "Загрузите документ (Excel, Word, PDF, TXT) или опишите задачу.\n"
            "Выберите режим работы на панели слева.\n"
            "Готовую смету можно выгрузить кнопкой «Выгрузить смету» (Excel и др.).\n"
            "Диалоги сохраняются автоматически — откройте их завтра через «Мои сметы».\n\n"
        )
        if not self.settings.is_configured:
            if self.settings.is_assistant_off:
                welcome += (
                    "ℹ️ Режим «Без помощника»: AI отключён.\n"
                    "Чтобы включить помощника, выберите OpenAI в настройках.\n"
                )
            else:
                provider = self.settings.get("provider", "openai")
                if provider == "llama_cpp":
                    welcome += (
                        "⚠️ Локальная модель не настроена:\n"
                        "   • положите Qwen2.5-14B-Instruct-IQ2_M.gguf в папку models/\n"
                        "   • llama-server.exe — в папку llama.cpp/\n"
                        "   • откройте «Настройки» и нажмите «Запустить сервер»\n"
                    )
                else:
                    welcome += (
                        "⚠️ Для начала работы откройте «Настройки»:\n"
                        "   • OpenAI — укажите API-ключ\n"
                        "   • Локально (llama.cpp) — положите модель и сервер\n"
                        "   • Без помощника — AI отключён\n"
                    )

        self._append_message("assistant", welcome)

    def _append_message(self, role: str, text: str, tag: str | None = None) -> None:
        labels = {
            "user": "Вы",
            "assistant": (
                "ИИ-бот по сметам" if self.current_mode == "bot" else "Помощник сметчика"
            ),
            "system": "Система",
            "error": "Ошибка",
        }
        label = labels.get(role, role)
        display_tag = tag or role

        timestamp = datetime.now().strftime("%H:%M")
        self.chat_display.insert("end", f"\n[{timestamp}] {label}:\n", display_tag)
        self.chat_display.insert("end", f"{text}\n", display_tag)
        self.chat_display.see("end")

    def _append_system_message(self, text: str) -> None:
        self._append_message("system", text)

    def _attach_file(self) -> None:
        if self.is_generating or self.is_loading_files:
            messagebox.showwarning(
                "Подождите",
                "Дождитесь завершения текущей операции.",
            )
            return

        filetypes = [
            ("Все поддерживаемые", "*.txt;*.md;*.csv;*.xlsx;*.xls;*.docx;*.pdf"),
            ("Excel", "*.xlsx;*.xls"),
            ("Word", "*.docx"),
            ("PDF", "*.pdf"),
            ("Текст", "*.txt;*.md;*.csv"),
        ]
        paths = filedialog.askopenfilenames(title="Выберите документ", filetypes=filetypes)
        if not paths:
            return

        self.is_loading_files = True
        self.status_label.configure(text="⏳ Загрузка документа...")

        thread = threading.Thread(
            target=self._parse_files_background,
            args=(list(paths),),
            daemon=True,
        )
        thread.start()

    def _parse_files_background(self, paths: list[str]) -> None:
        results: list[tuple[str, str, str]] = []
        errors: list[tuple[str, str]] = []

        for path in paths:
            try:
                content, doc_type = DocumentParser.parse(path)
                filename = Path(path).name
                results.append((filename, doc_type, content))
            except Exception as exc:
                errors.append((Path(path).name, str(exc)))

        self.after(0, lambda: self._on_files_parsed(results, errors))

    def _on_files_parsed(
        self,
        results: list[tuple[str, str, str]],
        errors: list[tuple[str, str]],
    ) -> None:
        self.is_loading_files = False

        for filename, doc_type, content in results:
            self.attached_files.append({
                "name": filename,
                "type": doc_type,
                "content": content,
            })
            self._append_message(
                "system",
                f"📎 Загружен: {filename}\n   Тип: {doc_type}\n   Размер: {len(content):,} символов",
                tag="file",
            )

        for filename, error in errors:
            messagebox.showerror("Ошибка", f"Не удалось загрузить {filename}:\n{error}")

        self._update_files_label()
        self.status_label.configure(text="")

        if self.current_mode == "audit" and self.attached_files and not self.is_generating:
            self.after(300, self._auto_start_audit)

    def _update_files_label(self) -> None:
        if self.attached_files:
            names = ", ".join(f["name"] for f in self.attached_files)
            self.files_label.configure(text=f"📎 Прикреплено: {names}")
        else:
            self.files_label.configure(text="")

    def _on_input_return(self, event: tk.Event) -> str | None:
        if event.state & 0x1:
            return None
        self._send_message()
        return "break"

    def _send_message(self, auto_text: str | None = None) -> None:
        if self.is_generating or self.is_loading_files:
            return

        text = auto_text if auto_text is not None else self.input_box.get("1.0", "end").strip()
        if not text and not self.attached_files:
            return

        # Подхватываем ключ из .env на случай правки файла вручную
        self.settings.reload_secrets()
        self.ai_client.reset_client()

        if not self.settings.is_configured:
            if self.settings.is_assistant_off:
                messagebox.showinfo(
                    "Без помощника",
                    "Сейчас выбран режим «Без помощника».\n"
                    "Запросы к AI не отправляются.\n\n"
                    "Чтобы включить помощника, откройте Настройки\n"
                    "и выберите OpenAI.",
                )
            else:
                messagebox.showwarning(
                    "Настройки",
                    "API-ключ не найден.\n\n"
                    "Сделайте одно из двух:\n"
                    "1) Вставьте ключ в Настройки и нажмите «Сохранить»\n"
                    "2) Впишите OPENAI_API_KEY=... в файл .env и сохраните файл (Ctrl+S),\n"
                    "   затем отправьте сообщение ещё раз.",
                )
            return

        if auto_text is None:
            self.input_box.delete("1.0", "end")

        user_content = text
        if self.attached_files:
            docs_parts = []
            for f in self.attached_files:
                content = DocumentParser.truncate_for_api(f["content"])
                docs_parts.append(
                    f"--- Документ: {f['name']} (тип: {f['type']}) ---\n{content}"
                )
            docs_text = "\n\n".join(docs_parts)
            if text:
                user_content = f"{text}\n\n{docs_text}"
            else:
                user_content = docs_text

        display_text = text or f"[Отправлено {len(self.attached_files)} документ(ов)]"
        self._append_message("user", display_text)
        self.messages.append({"role": "user", "content": user_content})
        self._autosave_session()

        self.attached_files.clear()
        self._update_files_label()

        self._start_generation()

    def _start_generation(self) -> None:
        self.is_generating = True
        self._cancel_event.clear()
        self._chunk_buffer = ""
        self._flush_scheduled = False
        self.send_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_label.configure(text="⏳ Генерация ответа... (может занять несколько минут)")

        mode = WORK_MODES[self.current_mode]
        mode_prompt = mode.get("prompt", "")
        system_prompt_id = mode.get("system_prompt", "app")

        self.chat_display.configure(state="normal")
        timestamp = datetime.now().strftime("%H:%M")
        assistant_label = (
            "ИИ-бот по сметам" if self.current_mode == "bot" else "Помощник сметчика"
        )
        self.chat_display.insert("end", f"\n[{timestamp}] {assistant_label}:\n", "assistant")
        self.chat_display.insert("end", "…", "assistant")
        self.response_start_index = self.chat_display.index("end-1c")

        thread = threading.Thread(
            target=self._generate_response,
            args=(mode_prompt, system_prompt_id),
            daemon=True,
        )
        thread.start()

    def _generate_response(self, mode_prompt: str, system_prompt_id: str = "app") -> None:
        full_response = ""
        try:
            def on_chunk(chunk: str) -> None:
                nonlocal full_response
                full_response += chunk
                self._chunk_buffer += chunk
                if not self._flush_scheduled:
                    self._flush_scheduled = True
                    self.after(UI_FLUSH_INTERVAL_MS, self._flush_chunk_buffer)

            full_response = self.ai_client.chat(
                self.messages,
                mode_prompt=mode_prompt,
                system_prompt_id=system_prompt_id,
                on_chunk=on_chunk,
                cancel_event=self._cancel_event,
            )
            self.after(0, self._flush_chunk_buffer)
            self.messages.append({"role": "assistant", "content": full_response})
            self.after(0, self._generation_done)

        except InterruptedError:
            self.after(0, lambda: self._generation_stopped(full_response))
        except Exception as exc:
            self.after(0, lambda: self._generation_error(str(exc)))

    def _flush_chunk_buffer(self) -> None:
        self._flush_scheduled = False
        if not self._chunk_buffer:
            return

        text = self._chunk_buffer
        self._chunk_buffer = ""
        self._remove_response_placeholder()
        self.chat_display.insert("end", text, "assistant")
        self.chat_display.see("end")

    def _remove_response_placeholder(self) -> None:
        try:
            content = self.chat_display.get(self.response_start_index, "end-1c")
            if content.strip() == "…":
                self.chat_display.delete(self.response_start_index, "end-1c")
        except (tk.TclError, AttributeError):
            pass

    def _append_chunk(self, chunk: str) -> None:
        self._chunk_buffer += chunk
        if not self._flush_scheduled:
            self._flush_scheduled = True
            self.after(UI_FLUSH_INTERVAL_MS, self._flush_chunk_buffer)

    def _generation_done(self) -> None:
        self._flush_chunk_buffer()
        self._remove_response_placeholder()
        self.chat_display.insert("end", "\n", "assistant")
        self._reset_generation_state()
        last = next(
            (m["content"] for m in reversed(self.messages) if m.get("role") == "assistant"),
            "",
        )
        if looks_like_estimate(last):
            self._append_system_message(
                "Смету можно выгрузить заказчику: кнопка «Выгрузить смету» "
                "(Excel, CSV, Word или Markdown)."
            )
        self._autosave_session()

    def _generation_stopped(self, partial: str) -> None:
        self._flush_chunk_buffer()
        if partial:
            self.messages.append({"role": "assistant", "content": partial})
        self._append_system_message("Генерация остановлена пользователем.")
        self._reset_generation_state()
        self._autosave_session()

    def _generation_error(self, error: str) -> None:
        self._flush_chunk_buffer()
        self._remove_response_placeholder()
        self._append_message("error", f"Ошибка: {error}")
        self._reset_generation_state()
        self._autosave_session()

    def _reset_generation_state(self) -> None:
        self.is_generating = False
        self.send_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_label.configure(text="")

    def _stop_generation(self) -> None:
        if not self.is_generating:
            return
        self._cancel_event.set()
        self.status_label.configure(text="⏳ Остановка...")
        self.stop_btn.configure(state="disabled")

    def _new_chat(self) -> None:
        if self.is_generating or self.is_loading_files:
            messagebox.showwarning("Подождите", "Дождитесь завершения текущей операции.")
            return

        if self.messages and not messagebox.askyesno(
            "Новый диалог",
            "Начать новый диалог?\n\nТекущая смета уже сохранена в «Мои сметы» "
            "и не исчезнет.",
        ):
            return

        self._autosave_session()
        self.current_session = ChatSession.create(mode=self.current_mode)
        self.messages.clear()
        self.attached_files.clear()
        self._update_files_label()
        enabled = self.settings.enabled_assistant_ids()
        self.current_mode = "free" if "free" in enabled else (enabled[0] if enabled else "free")
        self.current_session.mode = self.current_mode
        self._highlight_mode(self.current_mode)
        self._update_window_title()

        self.chat_display.delete("1.0", "end")
        self._show_welcome()

    def _open_sessions(self) -> None:
        if self.is_generating or self.is_loading_files:
            messagebox.showwarning("Подождите", "Дождитесь завершения текущей операции.")
            return
        self._autosave_session()
        SessionsDialog(self, self.session_store, on_open=self._load_session)

    def _autosave_session(self) -> None:
        if not self.messages:
            return
        try:
            self.session_store.update_from_chat(
                self.current_session,
                messages=self.messages,
                mode=self.current_mode,
            )
            self._update_window_title()
        except OSError as exc:
            self.status_label.configure(text=f"Не удалось сохранить: {exc}")

    def _restore_last_session(self) -> bool:
        session = self.session_store.load_last()
        if not session or not session.messages:
            return False
        self._load_session(session, announce=True)
        return True

    def _load_session(self, session: ChatSession, *, announce: bool = False) -> None:
        self.current_session = session
        self.messages = list(session.messages)
        self.attached_files.clear()
        self._update_files_label()

        mode = session.mode if session.mode in WORK_MODES else "free"
        if not self.settings.is_assistant_enabled(mode):
            enabled = self.settings.enabled_assistant_ids()
            mode = "free" if "free" in enabled else (enabled[0] if enabled else "free")
        self.current_mode = mode
        self._highlight_mode(mode)

        self.chat_display.delete("1.0", "end")
        for msg in self.messages:
            role = msg.get("role", "assistant")
            if role not in {"user", "assistant", "system", "error"}:
                role = "assistant"
            self._append_message(role, msg.get("content", ""))

        self.session_store.set_last_session_id(session.id)
        self._update_window_title()
        self._update_status_bar()

        if announce:
            when = str(session.updated_at).replace("T", " ")[:16]
            self._append_system_message(
                f"Открыта сохранённая смета «{session.title}» (обновлено: {when}).\n"
                "Можно продолжить работу или выгрузить файл заказчику."
            )

    def _update_window_title(self) -> None:
        title = self.current_session.title if self.messages else APP_NAME
        if self.messages:
            self.title(f"{title} — {APP_NAME}")
        else:
            self.title(f"{APP_NAME} v{APP_VERSION}")

    def _export_estimate(self) -> None:
        if not self.messages:
            messagebox.showinfo(
                "Выгрузка сметы",
                "Пока нет ответов помощника.\n"
                "Сначала составьте смету в диалоге, затем нажмите «Выгрузить смету».",
            )
            return

        table = extract_estimate_from_messages(self.messages)
        if not table or not table.has_data:
            messagebox.showwarning(
                "Выгрузка сметы",
                "В ответах помощника не найдена таблица сметы.\n\n"
                "Попросите помощника:\n"
                "«Составь смету таблицей: № | Наименование | Ед. изм. | "
                "Количество | Цена | Сумма»\n\n"
                "После этого снова нажмите «Выгрузить смету».",
            )
            return

        stamp = datetime.now().strftime("%Y%m%d_%H%M")
        path = filedialog.asksaveasfilename(
            title="Выгрузить смету для заказчика",
            defaultextension=".xlsx",
            initialfile=f"Smeta_{stamp}.xlsx",
            filetypes=[
                ("Excel", "*.xlsx"),
                ("CSV (Excel)", "*.csv"),
                ("Word", "*.docx"),
                ("Markdown", "*.md"),
                ("Текст", "*.txt"),
            ],
        )
        if not path:
            return

        try:
            saved = export_estimate(
                Path(path),
                table,
                currency=str(self.settings.get("currency", "руб.") or "руб."),
            )
        except Exception as exc:
            messagebox.showerror("Выгрузка сметы", f"Не удалось сохранить файл:\n{exc}")
            return

        self._append_system_message(
            f"Смета выгружена ({len(table.rows)} поз.): {saved.name}"
        )
        self.status_label.configure(text=f"Смета сохранена: {saved.name}")
        if messagebox.askyesno(
            "Выгрузка сметы",
            f"Файл сохранён:\n{saved}\n\nОткрыть папку с файлом?",
        ):
            try:
                import os

                os.startfile(str(saved.parent))  # noqa: S606 — Windows open folder
            except OSError:
                pass

    def _export_chat(self) -> None:
        if not self.messages:
            messagebox.showinfo("Экспорт", "Нет сообщений для экспорта.")
            return

        path = filedialog.asksaveasfilename(
            title="Сохранить диалог",
            defaultextension=".md",
            filetypes=[("Markdown", "*.md"), ("Текст", "*.txt")],
        )
        if not path:
            return

        lines = [f"# Диалог — {APP_NAME}", f"Дата: {datetime.now():%d.%m.%Y %H:%M}", ""]
        for msg in self.messages:
            role = "Пользователь" if msg["role"] == "user" else "Помощник"
            lines.append(f"## {role}\n\n{msg['content']}\n")

        Path(path).write_text("\n".join(lines), encoding="utf-8")
        messagebox.showinfo("Экспорт", f"Диалог сохранён:\n{path}")

    def _open_settings(self) -> None:
        SettingsDialog(self, self.settings, on_save=self._on_settings_saved)

    def _update_status_bar(self) -> None:
        provider = self.settings.get("provider", "openai")
        titles = {
            "openai": "OpenAI",
            "llama_cpp": "Локально (llama.cpp)",
            "none": "Без помощника",
        }
        provider_title = titles.get(provider, provider)
        normative = self.settings.get("normative_base", "")
        parts = [f"Провайдер: {provider_title}"]
        if provider == "llama_cpp":
            if self.settings.is_configured:
                parts.append("Модель: найдена")
            else:
                parts.append("Модель: не найдена")
            if self.ai_client.llama_server.is_responding():
                parts.append("Сервер: работает")
            else:
                parts.append("Сервер: не запущен")
        elif self.settings.is_configured:
            parts.append("Ключ: задан")
        elif not self.settings.is_assistant_off:
            parts.append("Ключ: не задан")
        if normative and normative != "Не указана":
            parts.append(f"База: {normative}")
        self.status_label.configure(text="\n".join(parts))

    def _on_settings_saved(self) -> None:
        self.settings.reload_secrets()
        self.ai_client.reset_client()
        self._apply_assistant_visibility()
        self._configure_chat_tags()
        self._update_status_bar()

        if (
            self.settings.get("provider") == "llama_cpp"
            and self.settings.get("llama_autostart", True)
            and not self.ai_client.llama_server.is_responding()
        ):
            self.after(500, self._autostart_llama)

    def _autostart_llama(self) -> None:
        if self.settings.get("provider") != "llama_cpp":
            return
        if self.ai_client.llama_server.is_responding():
            return

        self.status_label.configure(text="⏳ Запуск локальной модели...")

        def run() -> None:
            ok, msg = self.ai_client.llama_server.ensure_running()
            self.after(0, lambda: self._on_llama_autostart(ok, msg))

        threading.Thread(target=run, daemon=True).start()

    def _on_llama_autostart(self, ok: bool, msg: str) -> None:
        self._update_status_bar()
        if ok:
            self._append_system_message(f"Локальная модель готова. {msg}")
        else:
            self._append_system_message(f"Не удалось запустить локальную модель.\n{msg}")

    def _on_close(self) -> None:
        self._autosave_session()
        if self.settings.get("provider") == "llama_cpp":
            self.ai_client.llama_server.stop()
        self.destroy()
