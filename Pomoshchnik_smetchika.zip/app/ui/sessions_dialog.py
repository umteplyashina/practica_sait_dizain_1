"""Диалог сохранённых смет и диалогов."""

from __future__ import annotations

import customtkinter as ctk
from tkinter import messagebox, simpledialog

from app.services.session_store import SessionStore


class SessionsDialog(ctk.CTkToplevel):
    def __init__(self, parent, store: SessionStore, on_open=None):
        super().__init__(parent)
        self.store = store
        self.on_open = on_open
        self._items: list[dict] = []
        self._selected_id: str | None = None

        self.title("Мои сметы и диалоги")
        self.geometry("640x520")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        frame = ctk.CTkFrame(self, fg_color="transparent")
        frame.pack(fill="both", expand=True, padx=16, pady=16)

        ctk.CTkLabel(
            frame,
            text="Сохранённые сметы и диалоги",
            font=ctk.CTkFont(size=18, weight="bold"),
        ).pack(anchor="w")
        ctk.CTkLabel(
            frame,
            text="Откройте нужную смету — продолжите работу завтра или через неделю.",
            font=ctk.CTkFont(size=12),
            text_color="gray",
            wraplength=600,
            justify="left",
        ).pack(anchor="w", pady=(4, 12))

        self.listbox = ctk.CTkScrollableFrame(frame, height=340)
        self.listbox.pack(fill="both", expand=True)

        self.empty_label = ctk.CTkLabel(
            self.listbox,
            text="Пока нет сохранённых диалогов.\nСоставьте смету — она сохранится автоматически.",
            text_color="gray",
            justify="center",
        )

        btns = ctk.CTkFrame(frame, fg_color="transparent")
        btns.pack(fill="x", pady=(12, 0))

        ctk.CTkButton(btns, text="Открыть", width=120, command=self._open_selected).pack(
            side="left"
        )
        ctk.CTkButton(
            btns, text="Переименовать", width=130, fg_color="gray40", command=self._rename
        ).pack(side="left", padx=(8, 0))
        ctk.CTkButton(
            btns,
            text="Удалить",
            width=110,
            fg_color="#AA4444",
            hover_color="#883333",
            command=self._delete,
        ).pack(side="left", padx=(8, 0))
        ctk.CTkButton(btns, text="Закрыть", width=100, fg_color="gray40", command=self.destroy).pack(
            side="right"
        )

    def refresh(self) -> None:
        for child in self.listbox.winfo_children():
            child.destroy()

        self._items = self.store.list_sessions()
        self._selected_id = None

        if not self._items:
            self.empty_label = ctk.CTkLabel(
                self.listbox,
                text="Пока нет сохранённых диалогов.\nСоставьте смету — она сохранится автоматически.",
                text_color="gray",
                justify="center",
            )
            self.empty_label.pack(pady=40)
            return

        for item in self._items:
            self._add_row(item)

    def _add_row(self, item: dict) -> None:
        row = ctk.CTkFrame(self.listbox, fg_color=("gray90", "gray20"))
        row.pack(fill="x", pady=4)

        mark = "📊 " if item.get("has_estimate") else "💬 "
        title = f"{mark}{item.get('title') or 'Без названия'}"
        meta = (
            f"Обновлено: {str(item.get('updated_at', ''))[:16].replace('T', ' ')}  ·  "
            f"сообщений: {item.get('message_count', 0)}"
        )
        preview = item.get("preview") or ""

        ctk.CTkLabel(row, text=title, font=ctk.CTkFont(size=13, weight="bold"), anchor="w").pack(
            fill="x", padx=10, pady=(8, 0)
        )
        ctk.CTkLabel(row, text=meta, font=ctk.CTkFont(size=11), text_color="gray", anchor="w").pack(
            fill="x", padx=10
        )
        if preview:
            ctk.CTkLabel(
                row,
                text=preview,
                font=ctk.CTkFont(size=11),
                text_color=("gray30", "gray70"),
                anchor="w",
                wraplength=560,
                justify="left",
            ).pack(fill="x", padx=10, pady=(0, 8))
        else:
            ctk.CTkLabel(row, text="").pack(pady=(0, 6))

        def select(_event=None, sid=item["id"]):
            self._selected_id = sid
            self._highlight(sid)

        def open_item(_event=None, sid=item["id"]):
            self._selected_id = sid
            self._open_selected()

        for widget in (row, *row.winfo_children()):
            widget.bind("<Button-1>", select)
            widget.bind("<Double-Button-1>", open_item)

    def _highlight(self, session_id: str) -> None:
        # Visual feedback via refresh is heavy; keep selection in memory
        self._selected_id = session_id

    def _open_selected(self) -> None:
        if not self._selected_id:
            messagebox.showinfo("Мои сметы", "Выберите диалог из списка.", parent=self)
            return
        session = self.store.load(self._selected_id)
        if not session:
            messagebox.showerror("Мои сметы", "Не удалось открыть файл сессии.", parent=self)
            self.refresh()
            return
        if self.on_open:
            self.on_open(session)
        self.destroy()

    def _rename(self) -> None:
        if not self._selected_id:
            messagebox.showinfo("Мои сметы", "Выберите диалог.", parent=self)
            return
        current = self.store.load(self._selected_id)
        if not current:
            return
        new_title = simpledialog.askstring(
            "Переименовать",
            "Новое название:",
            initialvalue=current.title,
            parent=self,
        )
        if not new_title:
            return
        self.store.rename(self._selected_id, new_title)
        self.refresh()

    def _delete(self) -> None:
        if not self._selected_id:
            messagebox.showinfo("Мои сметы", "Выберите диалог.", parent=self)
            return
        if not messagebox.askyesno(
            "Удалить",
            "Удалить этот диалог/смету из приложения?\nФайл Excel на диске не удалится.",
            parent=self,
        ):
            return
        self.store.delete(self._selected_id)
        self._selected_id = None
        self.refresh()
