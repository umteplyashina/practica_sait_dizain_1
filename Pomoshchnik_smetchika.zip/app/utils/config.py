"""Управление настройками приложения."""

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from app.utils.constants import (
    CONFIG_DIR,
    DEFAULT_LLAMA_MODEL,
    ENV_EXAMPLE_FILE,
    ENV_FILE,
    SETTINGS_FILE,
)
from app.utils.env_store import (
    ENV_API_BASE_URL,
    ENV_API_KEY,
    ensure_env_file,
    load_env,
    read_secret,
    write_secrets,
)

DEFAULT_ENABLED_ASSISTANTS: dict[str, bool] = {
    "free": True,
    "bot": True,
    "audit": True,
    "rates": True,
    "compare": True,
    "explain": True,
    "expert": True,
}

DEFAULT_SECURITY: dict[str, bool] = {
    "mask_api_key": True,
    "confirm_show_key": True,
    "protect_env_file": True,
}

# Ключи, которые никогда не пишутся в settings.json
SENSITIVE_SETTING_KEYS = frozenset({"api_key"})

DEFAULT_SETTINGS: dict[str, Any] = {
    "provider": "llama_cpp",
    "api_key": "",
    "api_base_url": "http://127.0.0.1:8080/v1",
    "model": "Qwen2.5-14B-Instruct",
    "temperature": 0.3,
    "max_tokens": 4096,
    "theme": "dark",
    "normative_base": "",
    "currency": "руб.",
    "enabled_assistants": deepcopy(DEFAULT_ENABLED_ASSISTANTS),
    "security": deepcopy(DEFAULT_SECURITY),
    "llama_model_path": f"models/{DEFAULT_LLAMA_MODEL}",
    "llama_server_exe": "",
    "llama_host": "127.0.0.1",
    "llama_port": 8080,
    "llama_context_size": 8192,
    "llama_gpu_layers": -1,
    "llama_threads": 0,
    "llama_autostart": True,
}


class SettingsManager:
    def __init__(
        self,
        settings_path: Path = SETTINGS_FILE,
        env_path: Path = ENV_FILE,
    ) -> None:
        self.settings_path = settings_path
        self.env_path = env_path
        self._settings = deepcopy(DEFAULT_SETTINGS)
        self.load()

    def load(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ensure_env_file(self.env_path, ENV_EXAMPLE_FILE)
        load_env(self.env_path)

        if self.settings_path.exists():
            try:
                with open(self.settings_path, encoding="utf-8") as f:
                    loaded = json.load(f)
                self._settings.update(loaded)
            except (json.JSONDecodeError, OSError):
                pass

        self._migrate_provider()
        self._normalize_assistants()
        self._normalize_security()
        self._load_secrets_from_env()
        self._normalize_api_url()
        self._migrate_key_from_settings_json()

    def _normalize_security(self) -> None:
        current = self._settings.get("security")
        merged = deepcopy(DEFAULT_SECURITY)
        if isinstance(current, dict):
            for key in merged:
                if key in current:
                    merged[key] = bool(current[key])
        self._settings["security"] = merged

    def _load_secrets_from_env(self) -> None:
        api_key = read_secret(self.env_path, ENV_API_KEY)
        self._settings["api_key"] = api_key

        base_url = read_secret(self.env_path, ENV_API_BASE_URL)
        if base_url:
            self._settings["api_base_url"] = base_url

    def reload_secrets(self) -> None:
        """Перечитывает .env (например, после правки файла вручную)."""
        self._load_secrets_from_env()
        self._normalize_api_url()

    def _normalize_api_url(self) -> None:
        """Не даёт OpenAI-провайдеру случайно ходить на localhost."""
        provider = self.get("provider", "openai")
        url = str(self.get("api_base_url", "") or "").strip()
        is_local = "127.0.0.1" in url or "localhost" in url

        if provider == "openai" and is_local:
            self._settings["api_base_url"] = "https://api.openai.com/v1"
        elif provider == "llama_cpp":
            port = int(self.get("llama_port", 8080))
            self._settings["api_base_url"] = f"http://127.0.0.1:{port}/v1"

    def get_api_base_url(self) -> str:
        self._normalize_api_url()
        provider = self.get("provider", "openai")
        if provider == "llama_cpp":
            port = int(self.get("llama_port", 8080))
            host = str(self.get("llama_host", "127.0.0.1")).strip() or "127.0.0.1"
            return f"http://{host}:{port}/v1"
        return str(self.get("api_base_url", "") or "https://api.openai.com/v1").strip()

    def _migrate_key_from_settings_json(self) -> None:
        """Переносит ключ из старого settings.json в .env и очищает JSON."""
        legacy_key = ""
        if self.settings_path.exists():
            try:
                with open(self.settings_path, encoding="utf-8") as f:
                    raw = json.load(f)
                legacy_key = str(raw.get("api_key", "") or "").strip()
            except (json.JSONDecodeError, OSError, TypeError):
                legacy_key = ""

        if legacy_key and not self._settings.get("api_key"):
            self._settings["api_key"] = legacy_key

        if legacy_key:
            self._persist_secrets()
            self._scrub_settings_file()

    def _migrate_provider(self) -> None:
        """Старый провайдер Ollama больше не поддерживается."""
        if self._settings.get("provider") == "ollama":
            self._settings["provider"] = "openai"
            self._settings["api_base_url"] = "https://api.openai.com/v1"
            if not self._settings.get("model"):
                self._settings["model"] = "gpt-4o-mini"

    def _normalize_assistants(self) -> None:
        current = self._settings.get("enabled_assistants")
        merged = deepcopy(DEFAULT_ENABLED_ASSISTANTS)
        if isinstance(current, dict):
            for key in merged:
                if key in current:
                    merged[key] = bool(current[key])
        if not any(merged.values()):
            merged["free"] = True
        self._settings["enabled_assistants"] = merged

    def is_assistant_enabled(self, mode_id: str) -> bool:
        assistants = self.get("enabled_assistants", DEFAULT_ENABLED_ASSISTANTS)
        if not isinstance(assistants, dict):
            return True
        return bool(assistants.get(mode_id, True))

    def enabled_assistant_ids(self) -> list[str]:
        return [mid for mid in DEFAULT_ENABLED_ASSISTANTS if self.is_assistant_enabled(mid)]

    def get_security(self, key: str, default: bool = False) -> bool:
        security = self.get("security", DEFAULT_SECURITY)
        if not isinstance(security, dict):
            return default
        return bool(security.get(key, default))

    def _public_settings(self) -> dict[str, Any]:
        data = deepcopy(self._settings)
        for key in SENSITIVE_SETTING_KEYS:
            data.pop(key, None)
        return data

    def _persist_secrets(self) -> None:
        self._normalize_api_url()
        secrets = {
            ENV_API_KEY: str(self._settings.get("api_key", "") or "").strip(),
            ENV_API_BASE_URL: self.get_api_base_url(),
        }
        write_secrets(
            self.env_path,
            secrets,
            protect=self.get_security("protect_env_file", True),
        )

    def _scrub_settings_file(self) -> None:
        if not self.settings_path.exists():
            return
        try:
            with open(self.settings_path, encoding="utf-8") as f:
                raw = json.load(f)
        except (json.JSONDecodeError, OSError):
            return
        changed = False
        for key in SENSITIVE_SETTING_KEYS:
            if key in raw:
                raw.pop(key, None)
                changed = True
        if changed:
            with open(self.settings_path, "w", encoding="utf-8") as f:
                json.dump(raw, f, ensure_ascii=False, indent=2)

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._normalize_api_url()
        self._persist_secrets()
        with open(self.settings_path, "w", encoding="utf-8") as f:
            json.dump(self._public_settings(), f, ensure_ascii=False, indent=2)

    def clear_api_key(self) -> None:
        self._settings["api_key"] = ""
        self._persist_secrets()
        self._scrub_settings_file()

    def get(self, key: str, default: Any = None) -> Any:
        return self._settings.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._settings[key] = value

    def update(self, data: dict[str, Any]) -> None:
        self._settings.update(data)

    @property
    def all(self) -> dict[str, Any]:
        return deepcopy(self._settings)

    @property
    def is_configured(self) -> bool:
        provider = self.get("provider", "openai")
        if provider == "none":
            return False
        if provider == "llama_cpp":
            from app.services.llama_server import LlamaServerManager

            manager = LlamaServerManager(self)
            return manager.resolve_model_path() is not None
        return bool(self.get("api_key", "").strip())

    @property
    def is_assistant_off(self) -> bool:
        return self.get("provider", "openai") == "none"
