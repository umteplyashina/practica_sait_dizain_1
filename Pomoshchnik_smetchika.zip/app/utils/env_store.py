"""Хранение секретов в файле .env (не в settings.json)."""

from __future__ import annotations

import os
import re
import stat
from pathlib import Path

ENV_API_KEY = "OPENAI_API_KEY"
ENV_API_BASE_URL = "OPENAI_API_BASE_URL"

_ENV_PAIR = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$")


def ensure_env_file(env_path: Path, example_path: Path | None = None) -> None:
    """Создаёт .env из шаблона, если файла ещё нет."""
    if env_path.exists():
        return
    env_path.parent.mkdir(parents=True, exist_ok=True)
    if example_path and example_path.exists():
        env_path.write_text(example_path.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        env_path.write_text(
            "# Секреты приложения «Помощник сметчика»\n"
            "# Не передавайте этот файл и не публикуйте его в git.\n\n"
            f"{ENV_API_KEY}=\n"
            f"{ENV_API_BASE_URL}=https://api.openai.com/v1\n",
            encoding="utf-8",
        )
    protect_env_file(env_path)


def _strip_value(raw: str) -> str:
    text = raw.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
        text = text[1:-1]
    return text.strip()


def _parse_env_text(text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = _ENV_PAIR.match(line)
        if not match:
            continue
        key, value = match.group(1), _strip_value(match.group(2))
        result[key] = value
    return result


def load_env(env_path: Path) -> dict[str, str]:
    """Читает переменные из .env и подставляет в os.environ."""
    ensure_env_file(env_path)
    try:
        text = env_path.read_text(encoding="utf-8-sig")
    except OSError:
        return {}

    result = _parse_env_text(text)
    for key, value in result.items():
        # Всегда обновляем из файла — источник истины для ключа
        os.environ[key] = value
    return result


def read_secret(env_path: Path, key: str, default: str = "") -> str:
    data = load_env(env_path)
    return data.get(key, "").strip() or default


def write_secrets(
    env_path: Path,
    secrets: dict[str, str],
    *,
    protect: bool = True,
) -> None:
    """Надёжно обновляет значения в .env без потери остальных строк."""
    ensure_env_file(env_path)
    try:
        original = env_path.read_text(encoding="utf-8-sig")
    except OSError:
        original = ""

    lines = original.splitlines()
    remaining = dict(secrets)
    new_lines: list[str] = []

    for line in lines:
        match = _ENV_PAIR.match(line)
        if match and match.group(1) in remaining:
            key = match.group(1)
            new_lines.append(f"{key}={remaining.pop(key)}")
        else:
            new_lines.append(line)

    if remaining:
        if new_lines and new_lines[-1].strip():
            new_lines.append("")
        for key, value in remaining.items():
            new_lines.append(f"{key}={value}")

    content = "\n".join(new_lines).rstrip() + "\n"
    env_path.write_text(content, encoding="utf-8")

    if protect:
        protect_env_file(env_path)


def protect_env_file(env_path: Path) -> None:
    """Ограничивает права на файл (мягко, без ломки доступа)."""
    if not env_path.exists():
        return
    try:
        os.chmod(env_path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def mask_api_key(key: str) -> str:
    key = (key or "").strip()
    if not key:
        return ""
    if len(key) <= 8:
        return "*" * len(key)
    return f"{key[:4]}…{key[-4:]}"
