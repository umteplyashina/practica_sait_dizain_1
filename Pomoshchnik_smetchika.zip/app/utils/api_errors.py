"""Понятные сообщения об ошибках API."""

from __future__ import annotations

import re


def format_api_error(exc: Exception) -> str:
    text = str(exc).strip()
    lower = text.lower()

    if "unsupported_country_region_territory" in lower:
        return (
            "OpenAI недоступен из вашего региона (ошибка 403).\n\n"
            "Ключ может быть правильным, но прямой доступ к api.openai.com "
            "из этой страны заблокирован.\n\n"
            "Что можно сделать:\n"
            "1. В «Настройках» укажите URL совместимого API-провайдера "
            "(OpenAI-совместимый шлюз, OpenRouter, Azure OpenAI и т.п.).\n"
            "2. Вставьте API-ключ этого провайдера.\n"
            "3. Выберите модель, которую поддерживает провайдер "
            "(например gpt-4o-mini или аналог).\n"
            "4. Нажмите «Проверить подключение».\n\n"
            "Поле «URL API» должно заканчиваться на /v1, например:\n"
            "https://ваш-провайдер.example/v1"
        )

    if "invalid_api_key" in lower or "incorrect api key" in lower:
        return (
            "Неверный API-ключ (ошибка 401).\n\n"
            "Проверьте ключ в .env или в «Настройках» и сохраните заново."
        )

    if "insufficient_quota" in lower or "billing" in lower:
        return (
            "Недостаточно средств или лимит на аккаунте API.\n\n"
            "Пополните баланс у провайдера или выберите другую модель."
        )

    if "model_not_found" in lower or "does not exist" in lower:
        return (
            "Модель не найдена у выбранного провайдера.\n\n"
            "Укажите в настройках модель, которую поддерживает ваш API."
        )

    if "rate_limit" in lower or "429" in lower:
        return (
            "Превышен лимит запросов (ошибка 429).\n\n"
            "Подождите немного и попробуйте снова."
        )

    if "connection refused" in lower or "10061" in lower or "actively refused" in lower:
        return (
            "Локальный сервер llama.cpp не запущен или недоступен.\n\n"
            "1. Положите llama-server.exe в папку llama.cpp/\n"
            "2. Положите модель .gguf в папку models/\n"
            "3. В «Настройках» нажмите «Запустить сервер» или включите автозапуск\n"
            "4. Нажмите «Проверить подключение»"
        )

    if "connection" in lower or "timeout" in lower or "network" in lower:
        return (
            "Не удалось подключиться к API.\n\n"
            "Проверьте интернет, URL API и доступность провайдера."
        )

    # Убираем технический префикс "Error code: 403 - {...}"
    cleaned = re.sub(r"^Error code:\s*\d+\s*-\s*", "", text, flags=re.IGNORECASE)
    if cleaned != text:
        return f"Ошибка API:\n{cleaned}"
    return f"Ошибка API:\n{text}"
