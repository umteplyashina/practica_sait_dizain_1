"""Пути приложения (разработка и собранный .exe)."""

import sys
from pathlib import Path


def get_app_dir() -> Path:
    """Каталог приложения: рядом с .exe или корень проекта."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent.parent


def get_resource_dir() -> Path:
    """Каталог ресурсов: _MEIPASS в .exe или корень проекта."""
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)
    return get_app_dir()
