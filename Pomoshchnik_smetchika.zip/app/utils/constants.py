"""Константы приложения «Помощник сметчика»."""

from pathlib import Path

from app.utils.paths import get_app_dir, get_resource_dir

APP_NAME = "Помощник сметчика"
APP_VERSION = "1.3.0"

BASE_DIR = get_app_dir()
RESOURCE_DIR = get_resource_dir()
LLAMA_DIR = BASE_DIR / "llama.cpp"
MODELS_DIR = BASE_DIR / "models"
DEFAULT_LLAMA_MODEL = "Qwen2.5-14B-Instruct-IQ2_M.gguf"
DEFAULT_LLAMA_MODEL_ALIAS = "Qwen2.5-14B-Instruct"
CONFIG_DIR = BASE_DIR / "config"
DATA_DIR = BASE_DIR / "data"
SESSIONS_DIR = DATA_DIR / "sessions"
PROMPTS_DIR = RESOURCE_DIR / "prompts"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
ENV_FILE = BASE_DIR / ".env"
ENV_EXAMPLE_FILE = BASE_DIR / ".env.example"
SYSTEM_PROMPT_FILE = PROMPTS_DIR / "system_prompt.md"
PROMPT_FILENAME = "Промт для AI-приложения «Помощник сметчика».md"
BOT_PROMPT_FILENAME = "Промт для ИИ-бота по сметному делу в строительстве.md"

SUPPORTED_EXTENSIONS = {
    ".txt", ".md", ".csv",
    ".xlsx", ".xls",
    ".docx",
    ".pdf",
}

WORK_MODES = {
    "free": {
        "title": "Свободный диалог",
        "prompt": "",
        "system_prompt": "app",
        "icon": "💬",
    },
    "bot": {
        "title": "ИИ-бот по сметам",
        "prompt": (
            "Работай строго по алгоритму бота: сначала определи задачу пользователя, "
            "затем задавай только необходимые уточняющие вопросы (не все сразу), "
            "собирай данные, выполняй расчёт или анализ и завершай ответ итогом "
            "и предложением следующего шага. "
            "Если результат — смета или перечень работ со стоимостью, оформи его "
            "markdown-таблицей для выгрузки в Excel."
        ),
        "system_prompt": "bot",
        "icon": "🤖",
    },
    "audit": {
        "title": "Проверка сметы",
        "prompt": (
            "Режим «Проверка сметы». Выполни полный аудит предоставленного документа. "
            "Структура ответа:\n"
            "1. Общий результат проверки.\n"
            "2. Найденные ошибки (таблица с приоритетами).\n"
            "3. Подозрительные позиции.\n"
            "4. Пропущенные работы.\n"
            "5. Ошибки в объёмах.\n"
            "6. Ошибки в расценках.\n"
            "7. Ошибки в материалах.\n"
            "8. Ошибки в коэффициентах.\n"
            "9. Арифметическая проверка.\n"
            "10. Возможное влияние на итоговую стоимость.\n"
            "11. Рекомендации по исправлению."
        ),
        "system_prompt": "app",
        "icon": "🔍",
    },
    "rates": {
        "title": "Подбор расценки",
        "prompt": (
            "Режим «Подбор расценки». Проанализируй описание работы и предложи "
            "подходящие расценки. Выводи: рекомендуемую расценку, альтернативы, "
            "единицу измерения, состав работ, материалы, механизмы, коэффициенты "
            "и комментарий сметчика. Если информации недостаточно — задай 1–3 "
            "уточняющих вопроса."
        ),
        "system_prompt": "app",
        "icon": "📋",
    },
    "compare": {
        "title": "Найди ошибку",
        "prompt": (
            "Режим «Найди ошибку». Сравни предоставленные версии смет или данные "
            "построчно. Определи: изменившиеся позиции, объёмы, цены, добавленные "
            "и удалённые позиции, изменения коэффициентов и причину изменения "
            "итоговой суммы."
        ),
        "system_prompt": "app",
        "icon": "⚖️",
    },
    "explain": {
        "title": "Объяснить простыми словами",
        "prompt": (
            "Режим «Объяснить простыми словами». Дай короткий ответ, затем "
            "подробное объяснение, затем пример. Не перегружай нормативной "
            "терминологией."
        ),
        "system_prompt": "app",
        "icon": "📖",
    },
    "expert": {
        "title": "Режим эксперта",
        "prompt": (
            "Режим эксперта. Анализируй вопрос как опытный сметчик по логике: "
            "Исходные данные → нормативное основание → расчёт → проверка → вывод. "
            "В спорных ситуациях покажи несколько решений и риски каждого."
        ),
        "system_prompt": "app",
        "icon": "🎓",
    },
}

NORMATIVE_BASES = [
    "Не указана",
    "ФЕР",
    "ТЕР",
    "ГЭСН",
    "ТСН",
    "Коммерческая калькуляция",
    "Другая",
]

AVAILABLE_MODELS = [
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gpt-3.5-turbo",
]

API_PROVIDERS = {
    "openai": {
        "title": "OpenAI / совместимый API",
        "url": "https://api.openai.com/v1",
        "model": "gpt-4o-mini",
        "needs_key": True,
    },
    "llama_cpp": {
        "title": "Локально (llama.cpp + Qwen)",
        "url": "http://127.0.0.1:8080/v1",
        "model": DEFAULT_LLAMA_MODEL_ALIAS,
        "needs_key": False,
    },
    "none": {
        "title": "Без помощника",
        "url": "",
        "model": "",
        "needs_key": False,
    },
}
