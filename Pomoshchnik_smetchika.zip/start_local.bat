@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   Локальный сервер llama.cpp
echo   Модель: Qwen2.5-14B-Instruct-IQ2_M
echo ========================================
echo.

set "MODEL=models\Qwen2.5-14B-Instruct-IQ2_M.gguf"
set "SERVER="

if exist "llama.cpp\llama-server.exe" set "SERVER=llama.cpp\llama-server.exe"
if exist "llama.cpp\build\bin\Release\llama-server.exe" set "SERVER=llama.cpp\build\bin\Release\llama-server.exe"

if not defined SERVER (
    echo [ОШИБКА] llama-server.exe не найден.
    echo Положите сборку llama.cpp в папку llama.cpp\
    pause
    exit /b 1
)

if not exist "%MODEL%" (
    echo [ОШИБКА] Модель не найдена: %MODEL%
    echo Скопируйте Qwen2.5-14B-Instruct-IQ2_M.gguf в папку models\
    pause
    exit /b 1
)

echo Сервер: %SERVER%
echo Модель: %MODEL%
echo URL API: http://127.0.0.1:8080/v1
echo.
echo Для остановки нажмите Ctrl+C
echo.

"%SERVER%" -m "%MODEL%" --host 127.0.0.1 --port 8080 -c 8192 --alias Qwen2.5-14B-Instruct

pause
