# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec для сборки «Помощник сметчика» (без консоли)."""

import customtkinter
from pathlib import Path

block_cipher = None
root = Path(SPECPATH)

prompt_file = root / "Промт для AI-приложения «Помощник сметчика».md"
bot_prompt_file = root / "Промт для ИИ-бота по сметному делу в строительстве.md"
datas = [(str(Path(customtkinter.__file__).parent), "customtkinter")]

if prompt_file.exists():
    datas.append((str(prompt_file), "."))

if bot_prompt_file.exists():
    datas.append((str(bot_prompt_file), "."))

env_example = root / ".env.example"
if env_example.exists():
    datas.append((str(env_example), "."))

prompts_dir = root / "prompts"
if prompts_dir.exists():
    datas.append((str(prompts_dir), "prompts"))

a = Analysis(
    ["main.py"],
    pathex=[str(root)],
    binaries=[],
    datas=datas,
    hiddenimports=[
        "customtkinter",
        "PIL",
        "PIL._tkinter_finder",
        "openpyxl",
        "xlrd",
        "docx",
        "pypdf",
        "openai",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Помощник_сметчика",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="Помощник_сметчика",
)
