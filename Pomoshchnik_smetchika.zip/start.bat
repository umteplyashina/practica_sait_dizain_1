@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   Помощник сметчика v1.0
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ОШИБКА] Python не найден. Установите Python 3.10+ с https://python.org
    pause
    exit /b 1
)

if not exist "venv\" (
    echo Создание виртуального окружения...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Установка зависимостей...
pip install -r requirements.txt -q

echo.
echo Запуск приложения...
python main.py

pause
