@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "venv\Scripts\pythonw.exe" (
    echo [ОШИБКА] Не найдено виртуальное окружение.
    echo Сначала запустите start.bat один раз.
    pause
    exit /b 1
)

start "" "venv\Scripts\pythonw.exe" main.py
