' Тихий запуск «Помощник сметчика» без окна консоли
Option Explicit
Dim sh, fso, root, pythonw, mainPy
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw = root & "\venv\Scripts\pythonw.exe"
mainPy = root & "\main.py"
If Not fso.FileExists(pythonw) Then
  MsgBox "Не найдено виртуальное окружение." & vbCrLf & "Сначала один раз запустите start.bat.", vbCritical, "Помощник сметчика"
  WScript.Quit 1
End If
sh.CurrentDirectory = root
sh.Run """" & pythonw & """ """ & mainPy & """", 0, False
