@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   Сборка «Помощник сметчика» в .exe
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ОШИБКА] Python не найден.
    pause
    exit /b 1
)

if not exist "venv\" (
    echo Создание виртуального окружения...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Установка зависимостей...
pip install -r requirements.txt -q
pip install pyinstaller -q

echo.
echo Сборка exe (может занять несколько минут)...
pyinstaller smetchik.spec --noconfirm --clean

if errorlevel 1 (
    echo [ОШИБКА] Сборка не удалась.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   Готово!
echo   Файл: dist\Помощник_сметчика\Помощник_сметчика.exe
echo ========================================
echo.
pause
